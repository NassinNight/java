import java.util.Comparator;

public class ComparatorCzas implements Comparator<Zadanie> {

    @Override
    public int compare(Zadanie o1, Zadanie o2) {
        return o1.data.compareTo(o2.data);
    }
}
