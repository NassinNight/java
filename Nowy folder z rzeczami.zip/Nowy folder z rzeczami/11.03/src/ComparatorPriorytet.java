import java.util.Comparator;

public class ComparatorPriorytet implements Comparator<Zadanie> {

    @Override
    public int compare(Zadanie o1, Zadanie o2) {
        return o1.priorytet - o2.priorytet;
    }
}
