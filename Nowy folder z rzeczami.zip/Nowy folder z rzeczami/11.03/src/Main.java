public class Main {
    public static void main(String[] args) {
        Pies p1 = new Pies(6,50,20);
        Pies p2 = new Pies(6,50,30);
        Pies p3 = new Pies(3,50,40);

        Kot k1 = new Kot();


        System.out.println("p1 equals p2 " + p1.equals(p2));
        System.out.println("p2 equals p1 " + p2.equals(p1));
        System.out.println("p1 equals p3 " + p1.equals(p3));
        System.out.println("kotek equals p1 " + k1.equals(p1));
    }
}