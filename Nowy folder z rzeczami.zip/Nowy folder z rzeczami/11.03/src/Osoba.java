public class Osoba {
    String imie;

    public Osoba(String imie) {
        this.imie = imie;
    }

    @Override
    public String toString() {
        return "Osoba{" +
                "imie='" + imie + '\'' +
                '}';
    }
}
