import java.util.Iterator;

public class Para implements Iterable<Osoba>{
    Osoba pierwszaosoba, drugaosoba;

    public Para(Osoba pierwszaosoba, Osoba drugaosoba) {
        this.pierwszaosoba = pierwszaosoba;
        this.drugaosoba = drugaosoba;
    }

    @Override
    public Iterator<Osoba> iterator() {
        return new ParaIterator(this);
    }
}
