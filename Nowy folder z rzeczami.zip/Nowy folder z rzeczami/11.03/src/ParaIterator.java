import java.util.Iterator;
import java.util.NoSuchElementException;

public class ParaIterator implements Iterator<Osoba> {

    Para paraDoIteracji;
    int index = -1;

    @Override
    public boolean hasNext() {
        return index < 1;
    }

    @Override
    public Osoba next() {
        index++;
        if (index==0) {
            return paraDoIteracji.pierwszaosoba;
        } else if (index==1) {
            return paraDoIteracji.drugaosoba;
        } else {
            throw new NoSuchElementException();
        }
    }

    @Override
    public void remove() {
        if(index==0) {
            paraDoIteracji.pierwszaosoba = null;
        } else if (index == 1) {
            paraDoIteracji.drugaosoba = null;
        } else {
            throw new NoSuchElementException();
        }
    }

    public ParaIterator(Para paraDoIteracji) {
        this.paraDoIteracji = paraDoIteracji;
    }
}
