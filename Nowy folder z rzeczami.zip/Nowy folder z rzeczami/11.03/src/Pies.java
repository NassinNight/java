import java.util.Objects;

public class Pies {

    private int wiek;

    private int wzrost;

    private int waga;


    public Pies(int wiek, int wzrost, int waga) {
        this.wiek = wiek;
        this.wzrost = wzrost;
        this.waga = waga;
    }

    @Override
    public boolean equals(Object obj2) {
        Pies obj1 = this;


        if (obj1==obj2) return true;
        if (obj2 == null || obj1.getClass() != obj2.getClass()) return false;
        Pies obtemp = (Pies) obj2;
        return obj1.wiek==obtemp.wiek && obj1.wzrost== obtemp.wzrost;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getWiek(), wzrost);
    }

    public int getWiek() {
        return wiek;
    }

}
