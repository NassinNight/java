import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;

public class TestComp {
    public static void main(String [] args) {
        LocalDateTime localDateTime = LocalDateTime.now();
        LocalDateTime localDateTime1 = LocalDateTime.of(2023,3,10,13,12);


        Zadanie z1 = new Zadanie(1,"matma", localDateTime1);
        Zadanie z2 = new Zadanie(2,"fizyka", localDateTime);

        System.out.println(z1.compareTo(z2));
        System.out.println(z2.compareTo(z1));

        Comparator<Zadanie> priorytet = new ComparatorPriorytet();
        //Collections.sort();

        Comparator<Zadanie> czas = new ComparatorCzas();
        Comparator<Zadanie> priorytetiCzas = priorytet.thenComparing(czas);
    }
}
