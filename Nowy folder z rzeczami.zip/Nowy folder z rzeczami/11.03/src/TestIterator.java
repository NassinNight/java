import java.util.Iterator;

public class TestIterator {
    public static void main(String [] args) {
        Para para = new Para(new Osoba("Adam"),new Osoba("Ewa"));

        Iterator<Osoba> paraIterator = new ParaIterator(para);

        int i =0;
        while(paraIterator.hasNext()) {
            i++;
            System.out.println(paraIterator.next());
        }

        Para para2 = new Para(new Osoba("Jan"),new Osoba("Ewa"));

        Iterator<Osoba> paraIterator2 = para2.iterator();
        for(Osoba o: para2) {
            System.out.println(o);
        }
        int j =0;
        while(paraIterator.hasNext()) {
            j++;
            System.out.println(paraIterator.next());
        }
    }
}
