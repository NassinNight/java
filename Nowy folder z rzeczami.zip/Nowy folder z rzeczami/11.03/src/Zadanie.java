import java.time.LocalDateTime;

public class Zadanie implements Comparable<Zadanie>{

     int priorytet;
    String nazwa;
     LocalDateTime data;

//    @Override
//    public int compareTo(Zadanie o) {
//        return this.priorytet - o.priorytet;
//    }

    public Zadanie(int priorytet, String nazwa, LocalDateTime data) {
        this.priorytet = priorytet;
        this.nazwa = nazwa;
        this.data = data;
    }

    public int getPriorytet() {
        return priorytet;
    }

    public void setPriorytet(int priorytet) {
        this.priorytet = priorytet;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Zadanie{" +
                "priorytet=" + priorytet +
                ", nazwa='" + nazwa + '\'' +
                ", data=" + data +
                '}';
    }
    @Override
    public int compareTo(Zadanie o) {
        int roznicaPriorytetu = this.priorytet - o .priorytet;
        if (roznicaPriorytetu !=0) {
            return roznicaPriorytetu;
        } else {
            return this.data.compareTo(o.data);
        }
    }

}
