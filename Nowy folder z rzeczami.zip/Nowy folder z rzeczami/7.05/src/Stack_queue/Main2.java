package Stack_queue;

public class Main2 {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(3);
        System.out.println(stack.toString());
        System.out.println(stack.top().toString());
        System.out.println(stack.isEmpty());
        System.out.println(stack.isFull());
    }
}
