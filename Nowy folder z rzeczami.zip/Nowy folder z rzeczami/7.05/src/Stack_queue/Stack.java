package Stack_queue;


import java.util.Arrays;

public class Stack<T> implements IStack<T> {
    private static final int DEFAULT_SIZE=10;
    T [] array;
    int topIndex;

    @SuppressWarnings("unchecked")
    public Stack(int initialSize) {
        array= (T[])(new Object[initialSize]);

    }

    public Stack() {
        this(DEFAULT_SIZE);
    }




    @Override
    public boolean isEmpty() {
        return topIndex==0;
    }

    @Override
    public boolean isFull() {
        return topIndex== array.length;
    }

    @Override
    public T pop() {
        if(isEmpty()){
            return null;
        }else {
            return array[--topIndex];
        }
    }

    @Override
    public void push(T elem) {
        if(isFull()){
            System.out.println("stos pelny");
        } else {
            array[topIndex++]=elem;
        }
    }

    @Override
    public int size() {
        return topIndex;
    }

    @Override
    public T top() {
        if(isEmpty()){
            return null;
        } else {
            return array[topIndex-1];
        }
    }

    @Override
    public String toString() {
        return "Stack_queue.Stack{" +
                "array=" + Arrays.toString(array) +
                ", topIndex=" + topIndex +
                '}';
    }
}
