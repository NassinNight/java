package Zadania;

public interface IList<E> {
    boolean add(E e);
    boolean add(int index, E e);
    void clear();
    boolean contains(E e);
    E get(int index);
    E set(int index, E e);
    int indexOf(E e);
    boolean isEmpty();
    E remove(int index);
    boolean remove(E e);
    int size();
}
