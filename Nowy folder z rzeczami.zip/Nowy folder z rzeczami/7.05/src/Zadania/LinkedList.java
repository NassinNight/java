package Zadania;

public class LinkedList<E> extends MyArrayList<E> {
    private class element {
        private E value;
        private element next;

        element(E data) {
            this.value = data;

        }

        public E getValue() {
            return value;
        }

        public void setValue(E value) {
            this.value = value;
        }

        public element getNext() {
            return next;
        }

        public void setNext(element next) {
            this.next = next;
        }
    }

    element head = null;

    public LinkedList() {
    }

    ;

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public void clear() {
        head = null;
    }

    public int size() {
        int size = 0;
        element act = head;
        while (act != null) {
            size++;
            act = act = act.getNext();
        }
        return size;
    }

    private element getElement(int index) {
        element act = head;
        while (index > 0 && act != null) {
            index--;
            act = act.getNext();
        }

        return act;
    }

    public boolean add(E e) {
        element element = new element(e);
        if (head == null) {
            head = element;
            return true;
        }
        element tail = head;
        while(tail.getNext()!=null) {
            tail=tail.getNext();
        }
        tail.setNext(element);
        return true;
    }

    public boolean add(int index, E e) {
        if(index<0) return false;
        element element = new element(e);
        if(index==0) {
            element.setNext(head);
            head=element;
            return true;
        }
        element actelem = getElement(index-1);
        if(actelem==null) {
            return false;
        }
        element.setNext(actelem.getNext());
        actelem.setNext(element);
        return true;
    }

    @Override
    public E remove(int index) {
        if(head==null) return null;
        if (index==0) {
            E newval = head.getValue();
            head = head.getNext();
            return newval;
        }
        element actelem = getElement(index-1);
        if (actelem==null || actelem.getNext()==null) return null;

        E retvalue = actelem.getNext().getValue();
        actelem.setNext(actelem.getNext().getNext());
        return retvalue;
    }


    public String toString() {
        String result = "";
        element current = head;
        while (current != null) {
            result += current.getValue();
            result += ", ";
            current = current.getNext();
        }
        return "List: " + result;

    }

}

