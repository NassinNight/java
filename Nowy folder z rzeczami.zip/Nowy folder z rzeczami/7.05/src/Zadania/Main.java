package Zadania;

public class Main {
    public static void main(String[] args) {
        MyArrayList<Integer> lista = new MyArrayList<>();
        lista.add(8);
        lista.add(0,5);
        lista.add(3);
        lista.add(345);
        lista.add(2);
        System.out.println(lista.toString());

        lista.remove(0);
        System.out.println(lista.toString());

        lista.remove(lista.indexOf(8));
        System.out.println(lista.toString());

        lista.size();
        lista.contains(2);
        lista.isEmpty();
        lista.clear();

        LinkedList<Integer> linkedlist = new LinkedList<>();
        linkedlist.add(3);
        linkedlist.add(1);
        linkedlist.add(8);
        linkedlist.add(1);
        linkedlist.remove(0 );
        System.out.println(linkedlist.toString());

    }
}