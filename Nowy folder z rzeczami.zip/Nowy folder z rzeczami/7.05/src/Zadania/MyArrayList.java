package Zadania;

import java.util.Arrays;

public class MyArrayList<E> implements  IList<E>{
    private static final int DEFAULT_SIZE=10;
    private E [] array;
    private int inital_capacity;
    private int size;

    @SuppressWarnings("unchecked")
    public MyArrayList(int capacity) {
        if(capacity<=0) {
            capacity=DEFAULT_SIZE;
        }

        array = (E[])(new Object[capacity]);
        inital_capacity=capacity;
        size=0;

    }

    public MyArrayList() {
        this(DEFAULT_SIZE);
    }



    @SuppressWarnings("unchecked")
    private void ensureCapacity(int capacity) {
        if(array.length<capacity) {
            E[] copy = (E[])(new Object[capacity + capacity/2]);
            System.arraycopy(array,0,copy,0,size);
            array = copy;
        }
    }

    private void checkBounds(int index) {
        if (0 > index || index > size) {
        }
    }

    @Override
    public boolean add(E e) {
        ensureCapacity(size+1);
        array[size]=e;
        size++;
        return true;
    }

    @Override
    public boolean add(int index, E e) {
        if(index<0 || index>size)throw new IndexOutOfBoundsException();
        ensureCapacity(size+1);
        if(index!=size) {
            System.arraycopy(array,index,array,index+1,size-index);
        }
        array[index]=e;
        size++;
        return false;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void clear() {
        array = (E[])(new Object[inital_capacity]);
        size=0;
    }

    @Override
    public boolean contains(E e) {
        return indexOf(e) != -1;
    }

    @Override
    public E get(int index) {
        checkBounds(index);
        return array[index];
    }

    @Override
    public E set(int index, E e) {
        checkBounds(index);
        E resValue = array[index];
        array[index]=e;
        return resValue;
    }

    @Override
    public int indexOf(E e) {
        int index=-1;
        for(int i=0; i<size; i++) {
            if(array[i].equals(e)) {
                index=i;
            }
        }
        return index;
    }

    @Override
    public boolean isEmpty() {
        return size==0;
    }

    @Override
    public E remove(int index) {
        checkBounds(index);
        E retValue = array[index];
        int copyFrom = index +1;
        if(copyFrom<size) {
            System.arraycopy(array,copyFrom,array,index,size-index);
        }
        --size;
        return retValue;
    }



    @Override
    public boolean remove(E e) {
        int myIndex = indexOf(e);
        if(myIndex!= -1 && myIndex<size) {
            remove((Integer) e);
        }
        return true;
    }

    @Override
    public int size() {
        return array.length;
    }

    @Override
    public String toString() {
        return "Zadania.MyArrayList{" +
                "array=" + Arrays.toString(array) +
                ", inital_capacity=" + inital_capacity +
                ", size=" + size +
                '}';
    }
}

