import java.util.Comparator;

public class ComparatorRozszerzenia implements Comparator<Klasa> {
    @Override
    public int compare(Klasa o1, Klasa o2) {
        return o1.getRozszerzenia().compareTo(o2.getRozszerzenia());
    }
}
