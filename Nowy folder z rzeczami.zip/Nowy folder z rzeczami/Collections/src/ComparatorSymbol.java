import java.util.Comparator;

public class ComparatorSymbol implements Comparator<Klasa> {
    @Override
    public int compare(Klasa o1, Klasa o2) {
        return o1.getSymbol().compareTo(o2.getSymbol());
    }

}
