import java.util.Objects;

public class Klasa {
    private String symbol;
    private String rozszerzenia;
    private Wychowawca wychowawca;

    public Klasa(String symbol, String rozszerzenia, Wychowawca wychowawca) {
        this.symbol = symbol;
        this.rozszerzenia = rozszerzenia;
        this.wychowawca = wychowawca;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Klasa)) return false;
        Klasa klasa = (Klasa) o;
        return Objects.equals(getSymbol(), klasa.getSymbol()) && Objects.equals(getRozszerzenia(), klasa.getRozszerzenia()) && Objects.equals(getWychowawca(), klasa.getWychowawca());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSymbol(), getRozszerzenia(), getWychowawca());
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getRozszerzenia() {
        return rozszerzenia;
    }

    public void setRozszerzenia(String rozszerzenia) {
        this.rozszerzenia = rozszerzenia;
    }

    public Wychowawca getWychowawca() {
        return wychowawca;
    }

    public void setWychowawca(Wychowawca wychowawca) {
        this.wychowawca = wychowawca;
    }

    @Override
    public String toString() {
        return "Klasa{" +
                "symbol='" + symbol + '\'' +
                ", rozszerzenia='" + rozszerzenia + '\'' +
                ", wychowawca=" + wychowawca +
                '}';
    }
}
