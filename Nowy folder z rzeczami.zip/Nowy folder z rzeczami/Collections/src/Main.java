import java.util.*;

public class Main {
    public static void main(String[] args){

        List<Klasa> szkola = new ArrayList<>();
        szkola.add(new Klasa("3B","matma", new Wychowawca()));
        szkola.add(new Klasa("4B","fizyka", new Wychowawca()));
        szkola.add(new Klasa("2B","polski", new Wychowawca()));
        szkola.add(1, new Klasa("1B", "angielski", new Wychowawca()));
        wyswietl(szkola);
        System.out.println(szkola.size());
        System.out.println("Testowanie comparatorow");

        ComparatorSymbol comparatorSymbol =new ComparatorSymbol();
        Collections.sort(szkola,comparatorSymbol);
        wyswietl(szkola);

        Collections.sort(szkola,new ComparatorRozszerzenia());
        wyswietl(szkola);

//        Comparator<Klasa> comparator = comparatorSymbol


    }

    public static void wyswietl(List<Klasa> klasy ) {
        Iterator<Klasa> iterator = klasy.iterator();
        int i=0;
        while(iterator.hasNext()) {
            i++;
            System.out.println("i " + iterator.next().toString());
        }
    }
}