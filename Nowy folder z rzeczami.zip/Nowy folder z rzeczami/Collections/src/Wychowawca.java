public class Wychowawca {
    private String imie;
    private String nazwisko;
    private String przedmiot;
    public Wychowawca() {
        imie = "Jan";
        nazwisko = "Nowak";
        przedmiot = "matematyka";
    }

    public Wychowawca(String imie, String nazwisko, String przedmiot) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.przedmiot = przedmiot;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public String getPrzedmiot() {
        return przedmiot;
    }

    public void setPrzedmiot(String przedmiot) {
        this.przedmiot = przedmiot;
    }

    @Override
    public String toString() {
        return "Wychowawca{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", przedmiot='" + przedmiot + '\'' +
                '}';
    }
}
