import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonFrame extends JFrame implements ActionListener {
    JLabel label;
    JPanel pinkPanel;
    JPanel orangePanel;
    JPanel bluePanel;
    JButton button;

    public ButtonFrame() {
        label = new JLabel();
        label.setText("aaaaaa");

        ImageIcon icon = new ImageIcon(new ImageIcon("src/r.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
        label.setIcon(icon);
        label.setVerticalAlignment(JLabel.BOTTOM);
        label.setHorizontalAlignment(JLabel.RIGHT);
        label.setBounds(20, 20, 120, 90);

//        pinkPanel = new JPanel();
//        pinkPanel.setBackground(Color.PINK);
//        pinkPanel.setBounds(0, 0, 200, 200);
//        pinkPanel.setLayout(null);
//
//
//        orangePanel = new JPanel();
//        orangePanel.setBackground(Color.ORANGE);
//        orangePanel.setBounds(300, 0, 300, 200);
//        orangePanel.setLayout(null);
//
//        bluePanel = new JPanel();
//        bluePanel.setBackground(Color.BLUE);
//        bluePanel.setBounds(0, 300, 300, 200);
//        bluePanel.setLayout(null);

        button = new JButton();
        button.setText("bbbbb");
        button.setBackground(Color.cyan);
        button.setBounds(0, 0, 100, 100);
        button.addActionListener(this);

        this.setTitle("my frame");
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 800);
        this.setResizable(true);
        this.getContentPane().setBackground(new Color(0xA390CD));


        this.add(label);
//        this.add(pinkPanel);
//        this.add(orangePanel);
//        this.add(bluePanel);
        this.add(button);
        this.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e){
            if (e.getSource() == button) {
                MojaRamka ramka = new MojaRamka();
            }
        }
    }

