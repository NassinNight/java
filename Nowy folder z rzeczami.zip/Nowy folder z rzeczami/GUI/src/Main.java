import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        MojaRamka m1= new MojaRamka();
//        ButtonFrame b1 = new ButtonFrame();


//        JOptionPane.showMessageDialog(null, "this is info", "tytul okna", JOptionPane.WARNING_MESSAGE);
//        int odpowiedz = JOptionPane.showConfirmDialog(null, "czy chcesz kontynuowac?", "pytanie", JOptionPane.YES_NO_CANCEL_OPTION);
//        if (odpowiedz == 1) {
//            System.out.println("zgodziles sie");
//        String name = JOptionPane.showInputDialog("podaj imie");
//        System.out.println("czesc" + name);
        }
    }
