import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class MojaRamka extends JFrame implements ActionListener {

    JLabel label;
    JButton button;
    JPasswordField passwordField;
    public MojaRamka() {
        label = new JLabel();
        label.setText("aaaaaa");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.TOP);
        label.setBackground(Color.BLACK);
        label.setOpaque(true);
        label.setBounds(0,0,300,100);

        button = new JButton();
        button.setBounds(100,100,100,20);
        button.setVisible(true);
        button.addActionListener(this);

        passwordField = new JPasswordField();
        passwordField.setBounds(100,150,100,20);


        this.setTitle("my frame");
        this.setLayout(new FlowLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300, 300);
        this.setResizable(true);
        this.getContentPane().setBackground(new Color(0xA390CD));
        ImageIcon icon = new ImageIcon(new ImageIcon("src/r.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
        label.setIcon(icon);





        this.add(label);
        this.setVisible(true);
        this.add(button);
        this.add(passwordField);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button) {
            char[] input = passwordField.getPassword();
            System.out.println(input);
            System.out.println(input.getClass());
            String password = String.valueOf(input);
            System.out.println(password);
        }
    }
}
