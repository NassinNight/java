package ankieta;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ankieta extends JFrame implements ActionListener, ChangeListener {
    JTextField imietextfield;
    JTextField nazwiskotextfield;
    JRadioButton radioButton1;
    JRadioButton radioButton2;
    JRadioButton radioButton3;
    JRadioButton radioButton4;

    JComboBox<String> comboBox;
    JTextField imie;
    JTextField nazwisko;
    JTextField tytul;
    JTextField klasa;
    JTextField rozszerzenie;
    JButton confirmbutton;
    ImageIcon icon;

    JLabel jeden;
    JLabel dwa;
    JLabel trzy;
    JLabel cztery;
    JLabel label;
    JLabel label2;

    public Ankieta() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 800);
        this.setLayout(null);
        this.setTitle("Ankieta");
        imie = new JTextField();
        imie.setText("Podaj imie");
        imie.setBounds(30, 100, 150, 50);
        imie.setBorder(null);
        imie.setHorizontalAlignment(SwingConstants.CENTER);
        imie.setEditable(false);
        imie.setBackground(Color.yellow);
        imie.setBorder(BorderFactory.createRaisedBevelBorder());


        imietextfield = new JTextField();
        imietextfield.setBounds(210, 100, 150, 50);
        imietextfield.setBorder(BorderFactory.createLoweredBevelBorder());
        imietextfield.setHorizontalAlignment(SwingConstants.CENTER);

        label = new JLabel();
        label.setBounds(390, 100, 50, 50);

        label.setIcon(icon);
        label.setOpaque(true);


        nazwisko = new JTextField();
        nazwisko.setText("Podaj nazwisko");
        nazwisko.setBounds(30, 180, 150, 50);
        nazwisko.setBorder(null);
        nazwisko.setHorizontalAlignment(SwingConstants.CENTER);
        nazwisko.setEditable(false);
        nazwisko.setBackground(Color.yellow);
        nazwisko.setBorder(BorderFactory.createRaisedBevelBorder());


        nazwiskotextfield = new JTextField();
        nazwiskotextfield.setBounds(210, 180, 150, 50);
        nazwiskotextfield.setBorder(BorderFactory.createLoweredBevelBorder());
        nazwiskotextfield.setHorizontalAlignment(SwingConstants.CENTER);


        tytul = new JTextField();
        tytul.setText("Ankieta");
        tytul.setBounds(175, 20, 150, 50);
        tytul.setHorizontalAlignment(SwingConstants.CENTER);
        tytul.setBorder(null);
        tytul.setEditable(false);
        tytul.setBackground(Color.yellow);
        tytul.setBorder(BorderFactory.createRaisedBevelBorder());


        klasa = new JTextField();
        klasa.setText("Podaj klase");
        klasa.setBounds(30, 260, 150, 50);
        klasa.setBorder(null);
        klasa.setHorizontalAlignment(SwingConstants.CENTER);
        klasa.setEditable(false);
        klasa.setBackground(Color.yellow);
        klasa.setBorder(BorderFactory.createRaisedBevelBorder());

        jeden = new JLabel("I");
        jeden.setBounds(214, 245, 40, 50);
        dwa = new JLabel("II");
        dwa.setBounds(259, 245, 40, 50);
        trzy = new JLabel("III");
        trzy.setBounds(304, 245, 40, 50);
        cztery = new JLabel("IV");
        cztery.setBounds(349, 245, 40, 50);


        confirmbutton = new JButton();
        confirmbutton.setText("CONFIRM");
        confirmbutton.setBounds(125, 420, 250, 50);
        confirmbutton.addActionListener(this);

        radioButton1 = new JRadioButton();
        radioButton1.setBounds(202, 260, 40, 50);


        radioButton2 = new JRadioButton();
        radioButton2.setBounds(249, 260, 40, 50);

        radioButton3 = new JRadioButton();
        radioButton3.setBounds(296, 260, 40, 50);

        radioButton4 = new JRadioButton();
        radioButton4.setBounds(341, 260, 40, 50);


        String[] rozszerzenia = {"mat-inf", "mat-fiz", "biol-chem", "IB"};
        comboBox = new JComboBox<>(rozszerzenia);
        comboBox.setBounds(200, 330, 170, 50);


        rozszerzenie = new JTextField();
        rozszerzenie.setText("Podaj rozszerzenie");
        rozszerzenie.setBounds(30, 330, 150, 50);
        rozszerzenie.setBorder(null);
        rozszerzenie.setHorizontalAlignment(SwingConstants.CENTER);
        rozszerzenie.setEditable(false);
        rozszerzenie.setBackground(Color.yellow);
        rozszerzenie.setBorder(BorderFactory.createRaisedBevelBorder());




        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(radioButton1);
        buttonGroup.add(radioButton2);
        buttonGroup.add(radioButton3);
        buttonGroup.add(radioButton4);

        this.add(label);
        this.add(jeden);
        this.add(dwa);
        this.add(trzy);
        this.add(cztery);
        this.add(tytul);
        this.add(imietextfield);
        this.add(nazwiskotextfield);
        this.add(comboBox);
        this.add(radioButton1);
        this.add(radioButton2);
        this.add(radioButton3);
        this.add(radioButton4);
        this.add(imie);
        this.add(nazwisko);
        this.add(klasa);
        this.add(rozszerzenie);
        this.add(confirmbutton);
        this.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==confirmbutton) {
            info info = new info(imietextfield.getText(), nazwiskotextfield.getText());
            this.dispose();

        }

    }

    @Override
    public void stateChanged(ChangeEvent e) {
            if( imietextfield.getText()!=null) {
                confirmbutton.setEnabled(false);
            }
            if( nazwiskotextfield.getText()!=null) {
                confirmbutton.setEnabled(false);
            }
            if (radioButton1.isSelected() || radioButton2.isSelected() || radioButton3.isSelected() || radioButton4.isSelected()) {
                confirmbutton.setEnabled(true);
            } else {
                confirmbutton.setEnabled(false);
            }

        if(imietextfield !=null) {
            icon = new ImageIcon(new ImageIcon("src/ankieta/l.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
        }
    }
}
