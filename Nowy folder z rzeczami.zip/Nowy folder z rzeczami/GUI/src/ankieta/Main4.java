package ankieta;

public class Main4 {
    public static void main(String[] args) {
        Ankieta a1 = new Ankieta();
    }
}
