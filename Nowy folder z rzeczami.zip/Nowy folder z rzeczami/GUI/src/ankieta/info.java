package ankieta;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class info  extends JFrame implements ActionListener, ChangeListener {
    JLabel label;



    public info(String imietextfield, String nazwiskotextfield) {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);
        this.setTitle("info");


        label = new JLabel();
        label.setBounds(100,100,500,50);
        label.setOpaque(true);
        label.setText("Czesc " + imietextfield + " " + nazwiskotextfield);
        this.add(label);
        this.setVisible(true);


    }




    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void stateChanged(ChangeEvent e) {

    }
}
