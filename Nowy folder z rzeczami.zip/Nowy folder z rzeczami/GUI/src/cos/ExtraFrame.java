package cos;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.security.Key;

public class ExtraFrame extends JFrame implements ActionListener, ChangeListener {
    JCheckBox checkbox;
    JButton submitbutton;
    JRadioButton pizzabutton;
    JRadioButton burgerbutton;
    JRadioButton makaronbutton;
    JSlider slider;
    JPanel sliderpanel;
    JLabel temperatura;
    JComboBox<String> combobox;
    JProgressBar progressbar;
    JButton wybierzkolor;
    JLabel napiskolor;
    JMenuBar menuBar;
    JMenu filemenu;
    JMenu helpmenu;
    JMenuItem exitmenu;
    JMenuItem savemenu;


    public ExtraFrame() {
        checkbox = new JCheckBox("Nie jestem robotem");
        checkbox.setFocusable(false);
        checkbox.setFont(new Font("Consolas",Font.PLAIN, 20));
        checkbox.setBounds(20,10,250,50);

        submitbutton= new JButton("Submit");
        submitbutton.addActionListener(this);
        submitbutton.setFocusable(false);
        submitbutton.setBounds(300,10,100,50);

        pizzabutton = new JRadioButton("Pizza");
        pizzabutton.addActionListener(this);
        pizzabutton.setFocusable(false);
        pizzabutton.setBounds(100,100,100,50);

        burgerbutton = new JRadioButton("Burger");
        burgerbutton.addActionListener(this);
        burgerbutton.setFocusable(false);
        burgerbutton.setBounds(200,100,100,50);

        makaronbutton = new JRadioButton("Makaron");
        makaronbutton.addActionListener(this);
        makaronbutton.setFocusable(false);
        makaronbutton.setBounds(300,100,100,50);

        temperatura = new JLabel();

        slider = new JSlider(0,100,50);
        slider.setPreferredSize(new Dimension(200,200));
        slider.setOrientation(SwingConstants.VERTICAL);
        slider.setPaintTicks(true);
        slider.setMajorTickSpacing(20);
        slider.setPaintLabels(true);
        slider.addChangeListener(this);

        sliderpanel = new JPanel();
        sliderpanel.setBounds(30,250,100,250);
        sliderpanel.add(slider);
        sliderpanel.add(temperatura);

        String [] zwierzeta = {"kotek","chomik", "jaszczurka"};
        combobox = new JComboBox<>(zwierzeta);
        combobox.addItem("pies");
        combobox.setBounds(260,300,200,50);
        combobox.setSelectedIndex(0);

        progressbar = new JProgressBar(0,100);
        progressbar.setBounds(40,530,400,50);
        progressbar.setOpaque(true);
        progressbar.setValue(100);

        wybierzkolor = new JButton("wybierz kolor");
        wybierzkolor.addActionListener(this);
        wybierzkolor.setBounds(250,600,200,50);

        napiskolor = new JLabel();
        napiskolor.setBackground(Color.PINK);
        napiskolor.setOpaque(true);
        napiskolor.setText("kolor");
        napiskolor.setBounds(30,600,200,100);

        exitmenu = new JMenuItem("exit");
        exitmenu.addActionListener(this);
        exitmenu.setMnemonic(KeyEvent.VK_E);

        savemenu = new JMenuItem("save");
        savemenu.addActionListener(this);
        savemenu.setMnemonic(KeyEvent.VK_S);

        helpmenu = new JMenu("help");

        filemenu = new JMenu("file");
        filemenu.add(exitmenu);
        filemenu.add(savemenu);
        filemenu.setMnemonic(KeyEvent.VK_F);

        menuBar = new JMenuBar();
        menuBar.add(filemenu);
        menuBar.add(helpmenu);








        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);


        ButtonGroup group = new ButtonGroup();
        group.add(pizzabutton);
        group.add(burgerbutton);
        group.add(makaronbutton);

        this.setJMenuBar(menuBar);
        this.add(menuBar);
        this.add(wybierzkolor);
        this.add(napiskolor);
        this.add(progressbar);
        this.add(combobox);
        this.add(sliderpanel);
        this.add(checkbox);
        this.add(submitbutton);
        this.add(burgerbutton);
        this.add(pizzabutton);
        this.add(makaronbutton);
        this.setVisible(true);


        odliczaj();
    }

    public void odliczaj() {
        int counter = 100;
        while (counter>0) {
            progressbar.setValue(counter);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            counter--;
        }
    }





    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == submitbutton) {
            System.out.println(checkbox.isSelected());
        }

        if(e.getSource() == wybierzkolor) {
            JColorChooser colorChooser = new JColorChooser();
            Color color = JColorChooser.showDialog(null,"Wybierz kolor: ", Color.black);
            napiskolor.setBackground(color);
        }

        if(e.getSource() == exitmenu) {
            System.exit(0);
        }

        if(e.getSource() == savemenu) {
            JOptionPane.showMessageDialog(null, "plik zostal zapisany");
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        temperatura.setText("C = " + slider.getValue());
    }
}
