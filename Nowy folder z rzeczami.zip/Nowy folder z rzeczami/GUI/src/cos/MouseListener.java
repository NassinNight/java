package cos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class MouseListener extends JFrame implements java.awt.event.MouseListener {
    JLabel label;

    public MouseListener() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);

        label = new JLabel();
        label.setBounds(10,10,200,300);
        label.setOpaque(true);
        label.setBackground(Color.yellow);
        label.addMouseListener(this);




        this.add(label);
        this.setVisible(true);

    }


    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("naciskasz i pusciles");
    }

    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("naciskasz");
        label.setBackground(Color.magenta);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        System.out.println("pusciles");
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println("najechales");
        label.setBackground(Color.black);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        System.out.println("opusciles");
        label.setBackground(Color.yellow);
    }
}
