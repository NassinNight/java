package cos;

import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class main3 {
    public static void main(String[] args) {
        ExtraFrame e1 = new ExtraFrame();
//        MouseListener mouseListener = new cos.MouseListener();
//        Klawiatura k1 = new Klawiatura();


    }
}
