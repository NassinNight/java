package kalkulator;

import javax.management.StringValueExp;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Kalkulator extends JFrame implements ActionListener {
   JTextField okno;
   JButton [] numerybuttons;
   JButton [] funkcjebuttons;
   JButton addbutton, subbutton, mulbutton, divbutton, delbutton, clrbutton, eqlbutton, decbutton;
   JPanel panel;


   double liczba1;
   double liczba2;
   double wynik;
   char operator;
   int dzialanie = 0;


    public Kalkulator() {
       funkcjebuttons = new JButton[8];
       numerybuttons = new JButton[10];

       this.getContentPane().setBackground(new Color(0xB2E8F3));

       this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       this.setSize(420,550);
       this.setLayout(null);

       okno=new JTextField();
       okno.setBounds(50,25,300,50);
        okno.setEditable(false);


        addbutton = new JButton("+");
        subbutton = new JButton("-");
        mulbutton = new JButton("*");
        divbutton = new JButton("/");
        delbutton = new JButton("del");
        clrbutton = new JButton("clr");
        eqlbutton = new JButton("=");
        decbutton = new JButton(".");


       funkcjebuttons[0]= addbutton;
       funkcjebuttons[1]= subbutton;
       funkcjebuttons[2]= mulbutton;
       funkcjebuttons[3]= divbutton;
       funkcjebuttons[4]= delbutton;
       funkcjebuttons[5]= clrbutton;
       funkcjebuttons[6]= eqlbutton;
       funkcjebuttons[7]= decbutton;

       for(int i=0; i<8; i++) {
           funkcjebuttons[i].setBorder(BorderFactory.createRaisedBevelBorder());

           funkcjebuttons[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));


           funkcjebuttons[i].addActionListener(this);
           funkcjebuttons[i].setOpaque(true);


           int finalI = i;
           funkcjebuttons[i].addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseEntered(java.awt.event.MouseEvent evt) {
                   funkcjebuttons[finalI].setBorder(BorderFactory.createLoweredBevelBorder());
                   funkcjebuttons[finalI].setForeground(Color.RED);
               }

               public void mouseExited(java.awt.event.MouseEvent evt) {
                   funkcjebuttons[finalI].setForeground(UIManager.getColor("black"));
                   funkcjebuttons[finalI].setForeground(UIManager.getColor("black"));
                   funkcjebuttons[finalI].setBorder(BorderFactory.createRaisedBevelBorder());


               }
           });
       }

       for(int i=0; i<10; i++) {
           numerybuttons[i] = new JButton(String.valueOf(i));
           numerybuttons[i].addActionListener(this);
           numerybuttons[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

           numerybuttons[i].setBorder(BorderFactory.createRaisedBevelBorder());
           numerybuttons[i].setOpaque(true);
           int finalI = i;
           numerybuttons[i].addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseEntered(java.awt.event.MouseEvent evt) {
                   numerybuttons[finalI].setForeground(Color.RED);
                   numerybuttons[finalI].setBorder(BorderFactory.createLoweredBevelBorder());

               }

               public void mouseExited(java.awt.event.MouseEvent evt) {
                   numerybuttons[finalI].setBorder(BorderFactory.createRaisedBevelBorder());

                   numerybuttons[finalI].setForeground(UIManager.getColor("black"));
                   numerybuttons[finalI].setForeground(UIManager.getColor("black"));


               }
           });

       }


       delbutton.setBounds(50,430,145,50);
       clrbutton.setBounds(205,430,145,50);

       panel = new JPanel();
       panel. setBounds(50,100,300,300);
       panel.setLayout(new GridLayout(4,4,10,10));
       panel.setBackground(new Color(0xB2E8F3));

       panel.add(numerybuttons[7]);
       panel.add(numerybuttons[8]);
       panel.add(numerybuttons[9]);
       panel.add(addbutton);
       panel.add(numerybuttons[4]);
       panel.add(numerybuttons[5]);
       panel.add(numerybuttons[6]);
       panel.add(subbutton);
       panel.add(numerybuttons[1]);
       panel.add(numerybuttons[2]);
       panel.add(numerybuttons[3]);
       panel.add(divbutton);
       panel.add(decbutton);
       panel.add(numerybuttons[0]);
       panel.add(eqlbutton);
       panel.add(mulbutton);
       okno.setOpaque(true);
       okno.setBorder(BorderFactory.createEtchedBorder(10,Color.gray,Color.black));
       this.add(okno);
       this.add(delbutton);
       this.add(clrbutton);
       this.add(panel);
       this.setResizable(false);
       this.setVisible(true);
   }


    @Override
    public void actionPerformed(ActionEvent e) {
       for(int i=0; i<10; i++) {
           if(e.getSource() == numerybuttons[i]) {
               okno.setText(okno.getText().concat(String.valueOf(i)));
           }
       }

       if(e.getSource() == decbutton) {
           okno.setText(okno.getText().concat(String.valueOf(".")));
           decbutton.setEnabled(false);
       }
        if(e.getSource() == addbutton) {
            decbutton.setEnabled(true);
            dzialanie=1;
            liczba1 = Double.parseDouble(okno.getText());
            operator = '+';
            okno.setText(" ");
        }
        if(e.getSource() == subbutton) {
            decbutton.setEnabled(true);
            dzialanie=2;
            liczba1 = Double.parseDouble(okno.getText());
            operator = '-';
            okno.setText(" ");
        }
        if(e.getSource() == mulbutton) {
            decbutton.setEnabled(true);
            dzialanie=3;
            liczba1 = Double.parseDouble(okno.getText());
            operator = '*';
            okno.setText(" ");
        }
        if(e.getSource() == divbutton) {
            decbutton.setEnabled(true);
            dzialanie=4;
            liczba1 = Double.parseDouble(okno.getText());
            operator = '/';
            okno.setText(" ");
        }

        if(e.getSource() == eqlbutton) {
            switch (dzialanie) {
                case 1:
                    wynik=liczba1+Double.parseDouble(okno.getText());
                    okno.setText(String.valueOf(wynik));
                    dzialanie=0;
                    decbutton.setEnabled(true);
                    break;
                case 2:
                    wynik=liczba1-Double.parseDouble(okno.getText());
                    okno.setText(String.valueOf(wynik));
                    dzialanie=0;
                    decbutton.setEnabled(true);
                    break;
                case 3:
                    wynik=liczba1*Double.parseDouble(okno.getText());
                    okno.setText(String.valueOf(wynik));
                    dzialanie=0;
                    decbutton.setEnabled(true);
                    break;
                case 4:
                    wynik=liczba1/Double.parseDouble(okno.getText());
                    okno.setText(String.valueOf(wynik));
                    dzialanie=0;
                    decbutton.setEnabled(true);
                    break;
            }


        }

        if(e.getSource() == delbutton) {
            String a = okno.getText();
            okno.setText(" ");
            for(int i=0; i<a.length()-1; i++) {
                okno.setText(okno.getText() + a.charAt(i));
            }
        }
        if(e.getSource() == clrbutton) {
            okno.setText(" ");

        }
    }
}
