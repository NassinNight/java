package kolko_i_krzyzyk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ThreadLocalRandom;

public class Gra extends JFrame implements ActionListener{
    JLabel label;
    JPanel panel;
    JButton button1;
    JButton button2;
    JButton button3;
    JButton button4;
    JButton button5;
    JButton button6;
    JButton button7;
    JButton button8;
    JButton button9;

    private int tura = ThreadLocalRandom.current().nextInt(0,2);

    int[][] matrix = new int[3][3];




    public Gra() {


        for (int i = 0; i < matrix.length; i++)
        {
            for (int j = 0; j < matrix[i].length; j++)
            {
                matrix[i][j]=2;
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        System.out.println("------");


        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 550);
        this.setLayout(null);
        panel = new JPanel();
        panel.setBounds(0,25,500,500);
        panel.setLayout(new GridLayout(3,3,0,0));
        panel.setBackground(new Color(0xB2E8F3));

        label = new JLabel();
        label.setText("Kolko i krzyzyk");
        label.setBounds(0,0,500,25);
        label.setBackground(new Color(0xB2E8F3));
        label.setHorizontalAlignment(SwingConstants.CENTER);


        button1 = new JButton();
        button2 = new JButton();
        button3 = new JButton();
        button4 = new JButton();
        button5 = new JButton();
        button6 = new JButton();
        button7 = new JButton();
        button8 = new JButton();
        button9 = new JButton();


        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(button5);
        panel.add(button6);
        panel.add(button7);
        panel.add(button8);
        panel.add(button9);

        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);
        button6.addActionListener(this);
        button7.addActionListener(this);
        button8.addActionListener(this);
        button9.addActionListener(this);




        this.add(label);
        this.add(panel);
        this.setVisible(true);






    }









    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button1 && tura==0) {
            button1.setText("X");
            tura=1;
            button1.setEnabled(false);
            matrix[0][0]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
            }
            System.out.println("------");
            if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
//                button1.setBorderPainted(new Color(Colorblack));
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("a");
            }
            if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
            if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (e.getSource() == button1 && tura == 1) {
            button1.setText("O");
            tura=0;
            button1.setEnabled(false);
            matrix[0][0]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button2 && tura==0) {
            button2.setText("X");
            tura=1;
            button2.setEnabled(false);
            matrix[0][1]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);

                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button2 && tura == 1) {
            button2.setText("O");
            tura=0;
            button2.setEnabled(false);
            matrix[0][1]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button3 && tura==0) {
            button3.setText("X");
            tura=1;
            button3.setEnabled(false);
            matrix[0][2]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button3 && tura == 1) {
            button3.setText("O");
            tura=0;
            button3.setEnabled(false);
            matrix[0][2]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button4 && tura==0) {
            button4.setText("X");
            tura=1;
            button4.setEnabled(false);
            matrix[1][0]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button4 && tura == 1) {
            button4.setText("O");
            tura=0;
            button4.setEnabled(false);
            matrix[1][0]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button5 && tura==0) {
            button5.setText("X");
            tura=1;
            button5.setEnabled(false);
            matrix[1][1]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button5 && tura == 1) {
            button5.setText("O");
            tura=0;
            button5.setEnabled(false);
            matrix[1][1]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button6 && tura==0) {
            button6.setText("X");
            tura=1;
            button6.setEnabled(false);
            matrix[1][2]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button6 && tura == 1) {
            button6.setText("O");
            tura=0;
            button6.setEnabled(false);
            matrix[1][2]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button7 && tura==0) {
            button7.setText("X");
            tura=1;
            button7.setEnabled(false);
            matrix[2][0]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button7 && tura == 1) {
            button7.setText("O");
            tura=0;
            button7.setEnabled(false);
            matrix[2][0]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button8 && tura==0) {
            button8.setText("X");
            tura=1;
            button8.setEnabled(false);
            matrix[2][1]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button8 && tura == 1) {
            button8.setText("O");
            tura=0;
            button8.setEnabled(false);
            matrix[2][1]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }


        if(e.getSource()==button9 && tura==0) {
            button9.setText("X");
            tura=1;
            button9.setEnabled(false);
            matrix[2][2]=0;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("a");
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        } else if (e.getSource() == button9 && tura == 1) {
            button9.setText("O");
            tura=0;
            button9.setEnabled(false);
            matrix[2][2]=1;
            for (int[] ints : matrix) {
                for (int anInt : ints) {
                    System.out.print(anInt);

                }
                System.out.println();
                if (matrix[0][0] == 0 && matrix[0][1] == 0 && matrix[0][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    button1.setBackground(Color.RED);
                    button1.setOpaque(true);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][0] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 0 && matrix[1][1] == 0 && matrix[1][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 0 && matrix[2][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 0 && matrix[1][1] == 0 && matrix[2][2] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 0 && matrix[1][1] == 0 && matrix[2][0] == 0) {
                    JOptionPane.showMessageDialog(null, "wygral krzyzyk", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[0][1] == 1 && matrix[0][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][0] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[1][0] == 1 && matrix[1][1] == 1 && matrix[1][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[2][0] == 1 && matrix[2][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
                if (matrix[0][2] == 1 && matrix[1][1] == 1 && matrix[2][0] == 1) {
                    JOptionPane.showMessageDialog(null, "wygralo kolko", "win", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            System.out.println("------");
        }
    }
}
