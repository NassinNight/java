package kolko_i_krzyzyk;

public class Main6 {
    public static void main(String[] args) {
        Gra gra = new Gra();


    }
}
