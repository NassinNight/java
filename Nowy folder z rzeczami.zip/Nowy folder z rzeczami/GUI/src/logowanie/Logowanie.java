package logowanie;

import javax.management.StringValueExp;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

public class Logowanie extends JFrame implements ActionListener, ChangeListener, DocumentListener {
    JTextField login;
    JPasswordField password;
    JButton confirm;
    JPanel panel;
    JMenuBar menuBar;
    JMenuItem exit;
    JProgressBar progressbar;

    Map<String, String> mapa;



    public Logowanie() {

        mapa = new HashMap<>();
        mapa.put("login", "haslo");

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);

        login = new JTextField();
        login.setBounds(125,167,250,50);
        login.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
        login.setToolTipText("Login");

        password = new JPasswordField();
        password.setBounds(125,267,250,50);
        password.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
        password.setToolTipText("Password");


        confirm = new JButton();
        confirm.setBounds(187,367,125,50);
        confirm.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        confirm.setText("CONFIRM");
        confirm.addActionListener(this);

        panel = new JPanel();
        panel. setBounds(0,0,500,800);
        panel.setLayout(null);
        panel.setBackground(new Color(0xB2E8F3));

        progressbar = new JProgressBar(0,100);
        progressbar.setBounds(40,700,400,50);
        progressbar.setOpaque(true);
        progressbar.setValue(0);
        progressbar.setBackground(new Color(0xB2E8F3));
        progressbar.setVisible(true);

        menuBar = new JMenuBar();
        menuBar.setVisible(true);
        menuBar.setBounds(0,0,500,30);

        exit = new JMenuItem("EXIT");
        exit.addActionListener(this);
        exit.setMnemonic(KeyEvent.VK_E);
        exit.addActionListener(this);
        menuBar.add(exit);

        panel.add(login);
        panel.add(password);
        panel.add(confirm);
        panel.add(progressbar);
        this.add(menuBar);
        this.add(panel);
        this.setVisible(true);

        while (true) {
            char[] input = password.getPassword();
            if(login.getText().length() == 0 || String.valueOf(input).length()==0) {
                confirm.setEnabled(false);
            } else {
                confirm.setEnabled(true);
            }
        }
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        int i=0;
        if(e.getSource()==confirm)
        {
            char[] input = password.getPassword();
            String password = String.valueOf(input);


            progressbar.setVisible(true);
            try
            {
                while(i<=100)
                {
                    Thread.sleep(50);
                    progressbar.paintImmediately(0, 0, 400, 50);
                    progressbar.setValue(i);
                    i++;
                }
            }
            catch(Exception e1)
            {
                System.out.print("Caughted exception is ="+e1);
            }
            Set<Map.Entry<String, String >> set = mapa.entrySet();
            for(Map.Entry<String,String> entry:set) {
                if (entry.getKey().equals(login.getText()) && entry.getValue().equals(password)) {
                    JOptionPane.showMessageDialog(null,"udalo sie zalogowac","logowanie",JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null,"sprobuj ponownie","logowanie",JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }

        if(e.getSource() == exit) {
            System.exit(0);
        }



    }



    @Override
    public void insertUpdate(DocumentEvent e) {

    }

    @Override
    public void removeUpdate(DocumentEvent e) {

    }

    @Override
    public void changedUpdate(DocumentEvent e) {

    }

        @Override
    public void stateChanged(ChangeEvent e) {

    }
}
