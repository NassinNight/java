package logowanie;

public class Main5 {
    public static void main(String[] args) {
        Logowanie logowanie = new Logowanie();
    }
}