public class English implements Language{
    @Override
    public void sayGreeting() {
        System.out.println("hi");
    }

    @Override
    public void sayGoodbye() {
        System.out.println("bye");
    }

    @Override
    public void sayThanks() {
        System.out.println("thanks");
    }
}
