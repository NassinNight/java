public interface Language {
    void sayGreeting();
    void sayGoodbye();
    void sayThanks();

}
