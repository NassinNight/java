public class Main {
    public static void main(String[] args) {
    Polish p1 = new Polish();
    English e1 = new English();
    Spanish s1 = new Spanish();
    p1.sayGreeting();
    p1.sayGoodbye();
    p1.sayThanks();
    System.out.println("----------");
    e1.sayGreeting();
    e1.sayGoodbye();
    e1.sayThanks();
    System.out.println("-----------");
    s1.sayGreeting();
    s1.sayGoodbye();
    s1.sayThanks();
    }
}