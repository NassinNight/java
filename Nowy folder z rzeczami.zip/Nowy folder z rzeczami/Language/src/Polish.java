public class Polish implements Language{


    @Override
    public void sayGreeting() {
        System.out.println("siema");
    }

    @Override
    public void sayGoodbye() {
        System.out.println("pa");
    }

    @Override
    public void sayThanks() {
        System.out.println("dziekuje");
    }
}
