public class Spanish implements Language{
    @Override
    public void sayGreeting() {
        System.out.println("que pasa");
    }

    @Override
    public void sayGoodbye() {
        System.out.println("nos vemos");
    }

    @Override
    public void sayThanks() {
        System.out.println("gracias");
    }
}
