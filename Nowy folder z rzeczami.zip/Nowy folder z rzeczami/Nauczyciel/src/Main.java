
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();

        try {
            Nauczyciel n1 = new Nauczyciel("Kacper", "Srodawa", "Matma", "aaaaa 11");
        } catch (NieprawidlowaWartoscException e) {
            System.out.println(e.getMessage());
        }

        Student s2 = new Student();
        int[][] tab = new int[10][2];
        System.out.println(s2.toString());
        for (int i = 1; i < tab.length; i++) {
            tab[i][0] = i;
            tab[i][1] = random.nextInt(1, 7);
            System.out.println(" " + tab[i][0] + " " + tab[i][1]);
        }
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Wpisz zmien aby zmienic ocene");
            System.out.println("Wpisz zakoncz aby zamknac dziennik");
            String komenda = scanner.next();
            switch (komenda) {
                case "zmien":
                    System.out.println("Podaj numer ucznia od 1-9 ktoremu chcesz zmienic ocene");
                    int uczen = -1;
                    try {
                        uczen = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println(e.getMessage());
                }
                    System.out.println("Podaj na jaka ocene od 1 do 6");
                    int ocena = 1;
                    try {
                        ocena = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println(e.getMessage());
                    }

                    tab[uczen][1] = ocena;
                    Student s1 = new Student();
                    System.out.println(s1.toString());
                    System.out.println(" Oceny: ");
                    for (int i = 1; i < tab.length; i++) {
                        for (int j = 0; j < tab[i].length; j++) {
                            System.out.print(tab[i][j] + " ");
                        }
                        System.out.print("\n");
                    }
                    break;
            }
            if (komenda.equals("zakoncz")) {
                break;
            }

        }
    }
}