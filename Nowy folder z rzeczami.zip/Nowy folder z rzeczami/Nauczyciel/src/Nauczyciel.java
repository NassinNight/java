public class Nauczyciel {
    private String imie;
    private String nazwisko;
    private String przedmiot;
    private String adres;

    public Nauczyciel(String imie, String nazwisko, String przedmiot, String adres) throws  NieprawidlowaWartoscException {
        if (imie==null) {
            throw new NieprawidlowaWartoscException("Musisz podac imie");
        }
        if (nazwisko==null) {
            throw new NieprawidlowaWartoscException("Musisz podac nazwisko");
        }
        if (przedmiot==null) {
            throw new NieprawidlowaWartoscException("Musisz podac przedmiot");
        }

        this.imie=imie;
        this.nazwisko=nazwisko;
        this.przedmiot=przedmiot;
    }
}
