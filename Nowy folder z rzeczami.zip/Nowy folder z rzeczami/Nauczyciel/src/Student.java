import java.util.Arrays;

public class Student {
    private String imie;
    private String nazwisko;
    private int indeks;
    private int[] oceny;

    public Student() {
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.indeks=indeks;
        this.oceny=oceny;
    }

    public Student(String imie, String nazwisko, int indeks, int[] oceny) {
        imie="Kacper";
        nazwisko="Srodawa";
        indeks=1;
        oceny= new int[3];
    }

    @Override
    public String toString() {
        return "Student{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", indeks=" + indeks +
                ", oceny=" + Arrays.toString(oceny) +
                '}';
    }
}
