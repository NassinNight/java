import java.io.Serializable;

public class Adres implements Serializable {
    private String ulica;
    private int nr_domu;
    private int nr_mieszkania;
    private int kod_pocztowy;
    private String miasto;


    public Adres() {
        ulica= "warszawska";
        nr_domu=13;
        nr_mieszkania=2;
        kod_pocztowy=10000;
        miasto="krakow";

    }


    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public int getNr_domu() {
        return nr_domu;
    }

    public void setNr_domu(int nr_domu) {
        this.nr_domu = nr_domu;
    }

    public int getNr_mieszkania() {
        return nr_mieszkania;
    }

    public void setNr_mieszkania(int nr_mieszkania) {
        this.nr_mieszkania = nr_mieszkania;
    }

    public String getMiasto() {
        return miasto;
    }

    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public int getKod_pocztowy() {
        return kod_pocztowy;
    }

    public void setKod_pocztowy(int kod_pocztowy) {
        this.kod_pocztowy = kod_pocztowy;
    }

    @Override
    public String toString() {
        return "Adres{" +
                "ulica='" + ulica + '\'' +
                ", nr_domu=" + nr_domu +
                ", nr_mieszkania=" + nr_mieszkania +
                ", kod_pocztowy=" + kod_pocztowy +
                ", miasto='" + miasto + '\'' +
                '}';
    }
}
