import java.io.*;

public class Deserializacja {
    public static void main(String[] args) {
        try {
            FileInputStream stream = new FileInputStream("adres.ser");
            ObjectInputStream os = new ObjectInputStream(stream);

            Object object =os.readObject();

            Adres a1 = (Adres) object;

            System.out.println(a1.getMiasto());

            os.close();


        } catch (IOException | ClassNotFoundException e)  {
            System.out.println(e.getMessage());
        }
    }
}