public abstract class Bryla {
    protected String nazwa;
    protected int wysokosc;

    public Bryla() {
        nazwa="";
        wysokosc=0;
    }


    public Bryla(String nazwa, int wysokosc) {
        this.nazwa = nazwa;
        this.wysokosc = wysokosc;
    }

    public abstract double objetosc();
    public abstract double pole();

    public String toString() {
        return "Bryla{" +
                "nazwa='" + nazwa + '\'' +
                ", wysokosc=" + wysokosc +
                '}';
    }
}
