public class Main {
    public static void main(String[] args) {
        Prostopadloscian p1 = new Prostopadloscian("Bazowy", 1, 1, 1);
        Walec w1 = new Walec("Bazowy", 1, 1);
        System.out.println(p1);
        System.out.println(p1.objetosc());
        System.out.println(p1.pole());
        System.out.println(p1.czySzczescian());

        System.out.println("------------------");

        System.out.println(w1);
        System.out.println(w1.objetosc());
        System.out.println(w1.pole());

    }
}