public class Prostopadloscian extends Bryla{
    protected int a;
    protected int b;


    public Prostopadloscian(int a, int b) {
        a = 1;
        b = 1;
    }

    public Prostopadloscian(String nazwa, int wysokosc, int a, int b) {
        super(nazwa, wysokosc);
        this.a=a;
        this.b=b;
    }

    @Override
    public double objetosc() {
        return a*b*wysokosc;
    }

    @Override
    public double pole() {
        return (2*(a*b))+(2*(a*wysokosc))+(2*(b*wysokosc));
    }

    public boolean czySzczescian() {
        return a == b && b == wysokosc;
    }


    @Override
    public String toString() {
        return "Prostopadloscian{" +
                "a=" + a +
                ", b=" + b +
                ", nazwa='" + nazwa + '\'' +
                ", wysokosc=" + wysokosc +
                '}';
    }

}
