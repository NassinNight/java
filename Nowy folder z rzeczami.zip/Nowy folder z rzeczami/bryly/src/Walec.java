public class Walec extends Bryla {
    protected int r;

    public Walec(int r) {
        r=0;
    }

    public Walec(String nazwa, int wysokosc, int r) {
        super(nazwa, wysokosc);
        this.r = r;
    }

    @Override
    public double objetosc() {
        return 3.14*r*r*wysokosc;
    }

    @Override
    public double pole() {
        return 2*3.14*r*(r+wysokosc);
    }

    @Override
    public String toString() {
        return "Walec{" +
                "r=" + r +
                ", nazwa='" + nazwa + '\'' +
                ", wysokosc=" + wysokosc +
                '}';
    }
}
