public class Data {
    private int rok;
    private int miesiac;
    private int dzien;


    public Data(int rok, int miesiac, int dzien) {
        this.rok = rok;
        this.miesiac = miesiac;
        this.dzien = dzien;
    }


    public void setRok(int rok) {
        if (czy_dobry_rok(rok)) {
            this.rok = rok;
        } else {
            System.out.println("nieprawidlowy rok");
        }
        if (czy_rok_przestepny(rok)) {
            System.out.println("rok jest przestepny");
        } else {
            System.out.println("rok nie jest przestepny");
        }
    }


    public void setMiesiac(int miesiac) {
        if (czy_dobry_miesiac(miesiac)) {
            this.miesiac = miesiac;
        } else {
            System.out.println("nieprawidlowy miesiac");
        }
    }

    public void setDzien(int dzien) {
        if (czy_dobry_dzien(dzien)) {
            this.dzien = dzien;
        } else {
            System.out.println("nieprawidlowy dzien");
        }
    }
    public int getRok(int rok) {
        return rok;
    }

    public int getMiesiac(int miesiac) {
        return miesiac;
    }

    public int getDzien(int dzien) {
        return dzien;
    }

    private boolean czy_dobry_dzien(int dzien) {
        return dzien > 0 && dzien < 32;
    }
    private boolean czy_dobry_miesiac(int miesiac) {
        return miesiac > 0 && miesiac < 13;
    }
    private boolean czy_dobry_rok(int rok) {
        return rok > 0;
    }

    private boolean czy_rok_przestepny(int rok) {
        return rok % 4 == 0 && (rok % 100 != 0 || rok % 400 == 0);
    }

    public void ile_dni_ma_miesiac() {
        switch (miesiac) {
            case 1, 3, 5, 7, 8, 10, 12 -> System.out.println("31 dni");
            case 2 -> System.out.println("28 dni");
            case 4, 6, 9, 11 -> System.out.println("30 dni");
        }
    }

    public void porownanie_dat(Data Data) {
        if (rok>Data.rok || (rok==Data.rok && miesiac>Data.miesiac) || (rok==Data.rok && miesiac==Data.miesiac && dzien>Data.dzien)) {
            System.out.println("porownanie: -1");
        } else if (rok<Data.rok || (miesiac< Data.miesiac) || (dzien<Data.dzien)) {
            System.out.println("porownanie: 1");
        } else {
            System.out.println("porownanie: 0");
        }

    }

    public String toString() {
        return dzien + "." + miesiac + "." + rok;
    }



}
