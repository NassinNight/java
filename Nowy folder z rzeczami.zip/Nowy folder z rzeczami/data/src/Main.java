public class Main {
    public static void main(String[]args) {
        System.out.println("Data 1: ");
        Data d1 = new Data(2020,7,3);
        System.out.println(d1.toString());
        d1.setDzien(5);
        d1.setMiesiac(11);
        d1.setRok(2012);
        System.out.println(d1.toString());
        System.out.println("Data 2: ");
        Data d2 = new Data(2012,12,5);
        System.out.println(d2.toString());
        d1.porownanie_dat(d2);
        d1.ile_dni_ma_miesiac();

    }
}
