
public class Dom {
    private final String ulica;
    private final String miasto;
    private final int nr_domu;
    private final int kod_pocztowy;
    private final Mieszkancy[] mieszkancy = new Mieszkancy[5];

    public Dom(String ulica, String miasto, int nr_domu, int kod_pocztowy) {
        this.ulica=ulica;
        this.miasto=miasto;
        this.nr_domu=nr_domu;
        this.kod_pocztowy=kod_pocztowy;
    }

    public void dodaj_mieszkanca(Mieszkancy mieszkancy, int index) {
            this.mieszkancy[index]=mieszkancy;

    }

//    public void setKod_pocztowy(int kod_pocztowy) {
//        this.kod_pocztowy = kod_pocztowy;
//    }
//
//    public void setMiasto(String miasto) {
//        this.miasto = miasto;
//    }
//
//    public void setNr_domu(int nr_domu) {
//        this.nr_domu = nr_domu;
//    }
//
//    public void setUlica(String ulica) {
//        this.ulica = ulica;
//    }
//
//    public int getKod_pocztowy() {
//        return kod_pocztowy;
//    }
//
//    public int getNr_domu() {
//        return nr_domu;
//    }
//
//    public String getMiasto() {
//        return miasto;
//    }
//
//    public String getUlica() {
//        return ulica;
//    }
//
//    public void setMieszkancy(Mieszkancy[] mieszkancy) {
//        this.mieszkancy = mieszkancy;
//    }
//
//
//    public Mieszkancy[] getMieszkancy() {
//        return mieszkancy;
//    }



    public String toString() {
        return ulica + " " + miasto + " " + nr_domu + " " + kod_pocztowy;
    }
    public void wyswietl_mieszkancow() {
        int i;
        for (i = 0; i < mieszkancy.length; i++) {
            System.out.println(mieszkancy[i].toString());
        }
    }
}
