import java.util.Scanner;

public class Main {
    public static void main(String[]args) {
        Mieszkancy m1 = new Mieszkancy("Kacper", "Srodawa");
        Mieszkancy m2 = new Mieszkancy("Jan", "Nowak");
        Mieszkancy m6 = new Mieszkancy("Adam", "Kowalski");
        Mieszkancy m4 = new Mieszkancy("Julia", "Kowalczyk");
        Mieszkancy m5 = new Mieszkancy("Ania", "aaaaaaaaaaa");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj imie i nazwisko osoby ktora dodajesz");
        Mieszkancy m3 = new Mieszkancy(scanner.next(), scanner.next());
        Dom d1 = new Dom("Prosta","Leszno",17,64100);
        System.out.println(d1);
        d1.dodaj_mieszkanca(m1,0);
        d1.dodaj_mieszkanca(m2,1);
        d1.dodaj_mieszkanca(m6,2);
        d1.dodaj_mieszkanca(m4,3);
        d1.dodaj_mieszkanca(m5,4);
        d1.dodaj_mieszkanca(m3, scanner.nextInt());
        d1.wyswietl_mieszkancow();





    }
}
