public class Kot extends Zwierze{
    private String imie;
    private Wlasciciel wlasciciel;

    public Kot() {
        imie="Misty";
        wlasciciel= new Wlasciciel();
  //      System.out.println("jestem kotem");
    }

    public Kot(int wiek, String gatunek, int poziom_glodu, String imie, Wlasciciel wlasciciel) {
        super(wiek, gatunek, poziom_glodu);
        this.imie=imie;
        this.wlasciciel=wlasciciel;
    }
    public Kot(int wiek) {
        super(wiek,"ssak", 23);
        imie="tygrys";
        wlasciciel=new Wlasciciel();
    }




//    @Override
//    public String getGatunek() {
//        return super.getGatunek();
//    }
//
//    @Override
//    public int getPoziom_glodu() {
//        return super.getPoziom_glodu();
//    }
//
//    @Override
//    public int getWiek() {
//        return super.getWiek();
//    }

    public String getImie() {
        return imie;
    }

    public Wlasciciel getWlasciciel() {
        return wlasciciel;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setWlasciciel(Wlasciciel wlasciciel) {
        this.wlasciciel = wlasciciel;

    }


    @Override
    public String toString() {
        return "Kot{" +
                "imie='" + imie + '\'' +
                ", wlasciciel=" + wlasciciel +
                ", wiek=" + wiek +
                ", gatunek='" + gatunek + '\'' +
                ", poziom_glodu=" + poziom_glodu +
                '}';
    }

    @Override
    public void who_am_i() {
        super.who_am_i();
        System.out.println("jestem kotem");
    }
}

