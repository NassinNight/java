public class Main {
    public static void main(String[]args) {
//        Wlasciciel w1 = new Wlasciciel();
//        Kot k1 = new Kot();
//        Zwierze z1 = new Zwierze();
//        System.out.println(z1);
//        System.out.println(k1);
//        System.out.println(w1);
//        System.out.println(k1.getGatunek() + k1.getWiek() + k1.getPoziom_glodu());

        Zwierze z1 = new Zwierze();
        Zwierze z2 = new Kot();
        Kot k1 = new Kot(12,"wiek",20,"misty",new Wlasciciel("Kacper", "Srodawa"));
        Kot k2 = new Kot();

//        System.out.println(z1);
//        System.out.println(z2);


        z1.who_am_i();
        z2.who_am_i();
        k1.who_am_i();
        k2.who_am_i();

        System.out.println(k2);
    //    System.out.println(k1);



    }
}
