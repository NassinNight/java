public class Wlasciciel {
    private String imie;
    private String nazwisko;

    public Wlasciciel() {
        imie="Jan";
        nazwisko="Kowalski";
    }

    public Wlasciciel(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }



    public String toString() {
        return "Wlasciciel{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }

    p
}
