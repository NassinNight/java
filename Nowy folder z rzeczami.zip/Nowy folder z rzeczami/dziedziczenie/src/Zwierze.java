public class Zwierze {
    protected int wiek;
    protected String gatunek;
    protected int poziom_glodu;

    public Zwierze() {
        wiek=5;
        gatunek="ssak";
        poziom_glodu=100;
 //       System.out.println("jestem zwierzakiem");
    }

    public Zwierze(int wiek, String gatunek, int poziom_glodu) {
        this.wiek=wiek;
        this.gatunek=gatunek;
        this.poziom_glodu=poziom_glodu;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public String getGatunek() {
        return gatunek;
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public int getPoziom_glodu() {
        return poziom_glodu;
    }

    public void setPoziom_glodu(int poziom_glodu) {
        this.poziom_glodu = poziom_glodu;
    }

    public String toString() {
        return "Zwierze{" +
                "wiek=" + wiek +
                ", gatunek='" + gatunek + '\'' +
                ", poziom_glodu=" + poziom_glodu +
                '}';
    }
    public void who_am_i(){
        System.out.println("jestem zwierzakiem");
    }
}
