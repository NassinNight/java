import java.util.Scanner;

public class Hotel {
    protected Pokoj[][] hotel;
    protected int[] pokoj_na_pietrze;

    public Hotel() {
        hotel = new Pokoj[4][4];
        for (int i = 0; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                hotel[i][j] = new Pokoj(100*i+j+1, new Osoba());

            }
        }
    }

    public void dodajOsobe() {
        System.out.println("podaj ktore pietro");
        Scanner scanner = new Scanner(System.in);
        System.out.println("podaj numer pokoju");
        Scanner scanner1 = new Scanner(System.in);
        hotel[scanner.nextInt()][scanner1.nextInt()-1].setOsoba(new Osoba("aa", "bb"));
    }







    public void wyswietl() {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                System.out.print(hotel[i][j] + " ");
            }
            System.out.print("\n");
        }
    }


}