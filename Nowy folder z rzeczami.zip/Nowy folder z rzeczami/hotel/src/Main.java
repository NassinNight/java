import java.util.Random;

public class Main {
    public static void main(String[] Args) {
        Random random = new Random();
        Osoba o1 = new Osoba();
        Pokoj p1 = new Pokoj();
        System.out.println(p1.toString());
        Hotel h1 = new Hotel();
        h1.dodajOsobe();
        h1.wyswietl();
    }
}
