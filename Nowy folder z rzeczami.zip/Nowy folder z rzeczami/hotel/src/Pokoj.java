public class Pokoj {
    protected int numer;
    protected Osoba osoba;


    public Pokoj() {
        this.numer=101;
        this.osoba=new Osoba();
    }
    public Pokoj(int numer, Osoba osoba) {
        this.numer=numer;
        this.osoba=osoba;
    }

    public Pokoj(int numer) {
        this.numer = numer;
    }
    public Pokoj(Osoba osoba) {
        this.osoba = osoba;
    }

    public int getNumer() {
        return numer;
    }

    public void setNumer(int numer) {
        this.numer = numer;
    }

    public Osoba getOsoba() {
        return osoba;
    }

    public void setOsoba(Osoba osoba) {
        this.osoba = osoba;
    }

    public void czy_wolny_pokoj() {
        if (osoba==null) {
            System.out.println(numer);
        }
    }

    @Override
    public String toString() {
        return "Pokoj{" +
                "numer=" + numer +
                ", osoba=" + osoba +
                '}';
    }
}
