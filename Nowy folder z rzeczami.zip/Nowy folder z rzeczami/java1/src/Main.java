import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        int wiek;
//        wiek=21;
//        int liczba = 10;
//
//
//        boolean czy_pelnoletni = false;
//
//        char inicjal = 'M';
//
//        double cena = 12.3;
//        System.out.println(wiek);
//        System.out.println("Mam " +wiek + " lat");
//
//        final double PI = 3.14;
//        int liczba1 = 13;
//        int liczba2= 2;
//        int wynik = liczba1 % liczba2;
//        System.out.println(wynik);
//        double dodawanie = (double)liczba1+liczba2;
//        System.out.println(dodawanie);
//
//        liczba1 += 2;
//        System.out.println(liczba1);
//        liczba1 -= 3;
//        System.out.println(liczba1);
//        liczba1 *= 3;
//        System.out.println(liczba1);
//        liczba1 /= 2;
//        System.out.println(liczba1);
//
//        liczba1++;
//        System.out.println(liczba1);
//        liczba1--;
//        System.out.println(liczba1);
//
//
//        String imie = "Kacper";
//        System.out.println(imie);
//
//
        Scanner scanner = new Scanner(System.in);
//        System.out.println("Podaj imie: ");
//        String imie1 = scanner.next();
//        System.out.println(imie1);
//
//        System.out.println("Podaj wiek: ");
//        int wiek1 = scanner.nextInt();
//        System.out.println(wiek1);
//
//        int [] tablica = {2,4,3,1,3};
//        double [] tablica1 = new double[3];
//        tablica1[0] = 1.0;
//        tablica1[1] = 2.0;
//        tablica1[2] = 5.4;
//        System.out.println(tablica1[0]);
//        String [] tablica2 = {"Kacper", "Srodawa", "Poniec"};
//        System.out.println(tablica2[0] + tablica2[1] + tablica2[2]);
//       int [] tablica3 = {scanner.nextInt(), scanner.nextInt(), scanner.nextInt()};
//        System.out.println(tablica3[1]);
//
//        int bok1 = scanner.nextInt();
//        int bok2 = scanner.nextInt();
//        int wynik = bok1*2 + bok2*2;
//        System.out.println("Obwod: " + wynik + " Pole: " + bok1*bok2);
//
//
//        if (false) {
//            System.out.println("prawda");
//        } else {
//            System.out.println("falsz");
//        }
//
//
//        int liczba = scanner.nextInt();
//
//        if (liczba<18) {
//            System.out.println("nie jest");
//        } else {
//            System.out.println("jest");
//        }
//
//        int liczba1 = 10;
//        int liczba2 = 15;
//        if (liczba>=5 && liczba2<=20) {
//            System.out.println("prawda");
//        } else {
//            System.out.println("falsz");
//        }

//        int dzien = scanner.nextInt();
//        switch (dzien) {
//            case 1:
//                System.out.println("poniedzialek");
//                break;
//            case 2:
//                System.out.println("wtorek");
//                break;
//            case 3:
//                System.out.println("sroda");
//                break;
//            case 4:
//                System.out.println("czwartek");
//                break;
//            case 5:
//                System.out.println("piatek");
//                break;
//            case 6:
//                System.out.println("sobota");
//                break;
//            case 7:
//                System.out.println("niedziela");
//                break;
//
//        }


//        int licznik = 26;
//        while (licznik > 0) {
//            System.out.println(licznik);
//            licznik -= 5;
//        }
//
//        double[] tablica5 = {3.4, 5.6, 2.4, 7.8, 1992939.352533343};
//        for (int i = 4; i>=0; i--) {
//            System.out.println(tablica5[i]);––
//        }
//
//        for (double liczba : tablica5) {
//            System.out.println(liczba);
//        }
//
//        int [] tab = {1,2,3,4,5,6,7,8,9,10};
//        for (int liczba:tab) {
//            if (liczba%2==0) {
//                System.out.println(liczba);
//            }
//        }
//
//        String [] tab1 = {scanner.next(), scanner.next(), scanner.next()};
//        for (int i = 2;i>=0;i--) {
//            System.out.println(tab1[i]);
//        }
//        int [] tab2 = {scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt(), scanner.nextInt()};
//
//        int pomoc = tab2[0];
//
//        for (int i = 0; i < tab2.length; i++) {
//            if (pomoc <= tab2[i]) {
//                pomoc = tab2[i];
//            }
//        }
//        System.out.println(pomoc);
//
//
//        System.out.println("podaj 2 liczby " );
//        double [] tab4 = {scanner.nextInt(), scanner.nextInt()};
//        double wynik = 0.0;
//
//        System.out.println("co chcesz zrobic");
//        String dzialanie = scanner.next();
//
//        switch (dzialanie) {
//            case "mnozenie":
//                wynik=tab4[0]*tab4[1];
//                System.out.println(wynik);
//                break;
//            case "dodawanie":
//                wynik=tab4[0]+tab4[1];
//                System.out.println(wynik);
//                break;
//            case "odejmowanie":
//                wynik=tab4[0]-tab4[1];
//                System.out.println(wynik);
//                break;
//            case "dzielenie":
//                wynik= (double)tab4[0]/tab4[1];
//                System.out.println(wynik);
//                break;
//
//        }
//
//        int [] tab5 = {scanner.nextInt(),scanner.nextInt(),scanner.nextInt(),scanner.nextInt(),scanner.nextInt()};
//        int wynik1=0;
//        int pomoc1=tab5[0];
//        for (int i=0;i< tab5.length;i++) {
//            wynik1=pomoc1*tab5[i];
//            pomoc1=tab5[i];
//            System.out.println(wynik1);
//        }


    }
}
