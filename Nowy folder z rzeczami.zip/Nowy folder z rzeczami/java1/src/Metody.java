import java.util.Scanner;

public class Metody {
    public static void main(String[] args) {
        przywitanie("Kacper", 21);
        Scanner scanner = new Scanner(System.in);
        String dzialanie = scanner.next();
        switch (dzialanie) {
            case "dodawanie":
                System.out.println(dodawanie(scanner.nextInt(), scanner.nextInt()));
                break;
            case "odejmowanie":
                System.out.println(odejmowanie(scanner.nextInt(), scanner.nextInt()));
                break;
            case "mnozenie":
                System.out.println(mnozenie(scanner.nextInt(), scanner.nextInt()));
                break;
            case "dzielenie":
                System.out.println(dzielenie(scanner.nextInt(), scanner.nextInt()));
                break;


        }
    }

    public static void przywitanie(String imie, int wiek) {
        System.out.println("czesc " + imie);
    }

    public static int dodawanie(int liczba1, int liczba2) {
        int wynik=liczba1+liczba2;
        return wynik;
    }
    public static int odejmowanie(int liczba1, int liczba2) {
        int wynik1=liczba1-liczba2;
        return wynik1;
    }
    public static int mnozenie(int liczba1, int liczba2) {
        int wynik2=liczba1*liczba2;
        return wynik2;
    }
    public static int dzielenie(int liczba1, int liczba2) {
        int wynik3=liczba1/liczba2;
        return wynik3;
    }
}

