public class Osoba {

    //Pole klasy
    String imie;
    int wiek;
    double wzrost;

    //Konstruktory
        //Konstruktor domyslny
        public Osoba() {
            imie="Kacper";
            wiek=17;
            wzrost=188.0;
        }

        //Konstruktor przeciazony
        public Osoba(String imie, int wiek, double wzrost) {
            this.imie=imie;
            this.wiek=wiek;
            this.wzrost=wzrost;
        }
        public Osoba(String imie, int wiek) {
            this.imie=imie;
            this.wiek=wiek;
        }
        public Osoba(String imie, double wzrost) {
            this.imie = imie;
            this.wzrost = wzrost;
        }

        public void setImie(String imie) {
            this.imie=imie;
        }
        public void setWiek(int wiek) {
            this.wiek=wiek;
        }
        public void setWzrost(double wzrost) {
            this.wzrost=wzrost;
        }


        public String getImie() {
            return imie;
        }
        public int getWiek() {
            return wiek;
        }
        public double getWzrost() {
            return wzrost;
        }

        public void wyswietl() {
            System.out.println("Imie: " + imie + "\n wiek: " + wiek + "\n wzrost: " + wzrost);
        }
}
