import java.util.Scanner;

public class zadanie {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            int [] wynik = tablica(new int[5]);
//            for(int liczba:wynik) {
//                System.out.println(liczba);
//            }
            int [] tab2 = {3,5,6,7,8};
            add(tab2,scanner.nextInt(), scanner.nextInt());
            System.out.println(min(tab2,tab2[0]));

            for(int liczba:tab2) {
                System.out.println(liczba);
            }
        }

        public static int[] tablica(int[] tab) {
            Scanner scanner = new Scanner(System.in);

//            for(int i=0;i<5;i++) {
//                tab[i]=scanner.nextInt();
//            }
        return tab;
        }
        public static int[] add(int[] tablica, int index, int liczba) {
            Scanner scanner = new Scanner(System.in);

            while (index>=5 || index<0) {
                System.out.println("podaj inny index pomiedzy 0 a 4 ");
                index= scanner.nextInt();
            }
            tablica[index]=liczba;
            return tablica;
        }
        public static int min(int[] tablica, int pomoc) {
            for (int i = 0; i < tablica.length; i++) {
                if (pomoc >= tablica[i]) {
                    pomoc = tablica[i];
                }
            }
            return pomoc;
        }
}
