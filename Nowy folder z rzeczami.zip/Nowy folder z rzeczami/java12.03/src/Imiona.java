import java.util.Objects;

public class Imiona implements Comparable<Imiona>{
    private String imie;

    public Imiona(String imie) {
        this.imie = imie;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Imiona)) return false;
        Imiona imiona = (Imiona) o;
        return Objects.equals(getImie(), imiona.getImie());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getImie());
    }

    @Override
    public String toString() {
        return "Imiona{" +
                "imie='" + imie + '\'' +
                '}';
    }

    @Override
    public int compareTo(Imiona o) {
        return this.getImie().compareTo(o.getImie());
    }
}
