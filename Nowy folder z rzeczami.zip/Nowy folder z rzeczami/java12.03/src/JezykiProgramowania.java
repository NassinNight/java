import java.util.Iterator;
import java.util.Objects;
import java.util.Set;

public class JezykiProgramowania {
    private String nazwa;
    private int rokPowstania;

    public JezykiProgramowania(String nazwa, int rokPowstania) {
        this.nazwa = nazwa;
        this.rokPowstania = rokPowstania;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public int getRokPowstania() {
        return rokPowstania;
    }

    public void setRokPowstania(int rokPowstania) {
        this.rokPowstania = rokPowstania;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof JezykiProgramowania)) return false;
        JezykiProgramowania that = (JezykiProgramowania) o;
        return getRokPowstania() == that.getRokPowstania() && Objects.equals(getNazwa(), that.getNazwa());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNazwa(), getRokPowstania());
    }

    @Override
    public String toString() {
        return "JezykiProgramowania{" +
                "nazwa='" + nazwa + '\'' +
                ", rokPowstania=" + rokPowstania +
                '}';
    }

}
