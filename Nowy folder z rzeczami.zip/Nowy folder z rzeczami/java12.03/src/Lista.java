import java.util.Objects;

public class Lista implements Comparable<Lista>{
    public String imie;
    public int wiek;

    public Lista(String imie, int wiek) {
        this.imie = imie;
        this.wiek = wiek;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Lista)) return false;
        Lista lista = (Lista) o;
        return getWiek() == lista.getWiek() && Objects.equals(getImie(), lista.getImie());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getImie(), getWiek());
    }

    @Override
    public String toString() {
        return "Lista{" +
                "imie='" + imie + '\'' +
                ", wiek=" + wiek +
                '}';
    }



    @Override
    public int compareTo(Lista o) {
        return this.getImie().compareTo(o.getImie());
    }
}
