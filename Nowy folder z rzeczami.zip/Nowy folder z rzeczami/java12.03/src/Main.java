import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        System.out.println("testowanie hashset");
        Set<User> hashSet = new HashSet<>();
        hashSet.add(new User("kacper", "kacper1"));
        hashSet.add(new User("adam", "adam1"));
        hashSet.add(new User("asia", "asia1"));
        wyswietl(hashSet);
        System.out.println(hashSet.contains(new User("kacper", "kacper1")));
        System.out.println(hashSet.size());
        hashSet.remove(new User("asia", "asia1"));
        hashSet.add(null);
        wyswietl(hashSet);
        hashSet.clear();
        System.out.println(hashSet.isEmpty());




        System.out.println("testowanie treeset");

        Set<User> treeSet = new TreeSet<>(new ComparatorImie());
        treeSet.add(new User("kacper", "kacper1"));
        treeSet.add(new User("adam", "adam1"));
        treeSet.add(new User("asia", "asia1"));
        wyswietl(treeSet);




    }

    public static void wyswietl(Set<User> secik) {
        Iterator<User> iterator = secik.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}