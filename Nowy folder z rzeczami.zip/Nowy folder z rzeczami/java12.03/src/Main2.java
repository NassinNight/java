import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main2 {
    public static void main(String[]args) {
        Set<JezykiProgramowania> hashSet1 = new HashSet<>();
        hashSet1.add(new JezykiProgramowania("Python", 1990));
        hashSet1.add(new JezykiProgramowania("C++", 1980));
        hashSet1.add(new JezykiProgramowania("Ruby", 2000));
        hashSet1.add(new JezykiProgramowania("Java", 1975));
        hashSet1.add(new JezykiProgramowania("JavaScript", 2005));
        System.out.println(hashSet1.contains(new JezykiProgramowania("C++", 1980)));
        System.out.println(hashSet1.isEmpty());
        System.out.println(hashSet1.size());
        hashSet1.remove(new JezykiProgramowania("Java", 1975));
        wyswietl(hashSet1);

        hashSet1.clear();
        System.out.println(hashSet1.isEmpty());

    }
    public static void wyswietl(Set<JezykiProgramowania> set) {
        Iterator<JezykiProgramowania> iterator = set.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
