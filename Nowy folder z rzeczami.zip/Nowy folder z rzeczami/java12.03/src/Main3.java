import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main3 {
    public static void main(String[]args) {
        Set<Owoc> treeSet = new TreeSet<>();
        treeSet.add(new Owoc("jablko", "czerwone"));
        treeSet.add(new Owoc("banan", "zolty"));
        treeSet.add(new Owoc("mango", "pomaranczowe"));
        treeSet.add(new Owoc("Ananas", "Zolty"));
        treeSet.add(new Owoc("mandarynka", " pomaranczowe"));
        wyswietl(treeSet);
    }
    public static void wyswietl(Set<Owoc> set) {
        Iterator<Owoc> iterator = set.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
