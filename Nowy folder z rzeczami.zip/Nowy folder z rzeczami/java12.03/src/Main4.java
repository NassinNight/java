import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Main4 {
    public static void main(String[]args) {
        Scanner myObj = new Scanner(System.in);
        Set<Imiona> treeSet = new TreeSet<>();
        System.out.println("1 aby dodac imie, inna cyfra=stop");

        int choice = myObj.nextInt();
        while (true) {
            switch (choice) {
                case 1:
                    System.out.println("Podaj imie");
                    treeSet.add(new Imiona(myObj.next()));
                    System.out.println(" ");
                    wyswietl(treeSet);
                    System.out.println(" ");
                    System.out.println("Podaj numer");
                    choice = myObj.nextInt();
                case 0:
                    break;
            }
            if (choice == 0) {
                break;
            }
        }
        System.out.println(treeSet.size());



    }
    public static void wyswietl(Set<Imiona> set) {
        Iterator<Imiona> iterator = set.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
