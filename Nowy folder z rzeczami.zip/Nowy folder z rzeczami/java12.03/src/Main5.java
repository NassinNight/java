import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main5 {
    public static void main(String[]args) {
        Map<String, Integer> myMap = new HashMap<>();
        myMap.put("Kacper", 18);
        myMap.put("Adam", 30);
        wyswietl(myMap);


        Map<User, Boolean> users = new HashMap<>();
        users.put(new User("ms", "ms@wp.pl"), true);
        users.put(new User("asa", "asa123"), false);
        users.put(new User("ms", "ms@wp.pl"), true);
        wyswietl(users);


        Map<User, Integer> mapa = new TreeMap<>(new TreeMap<>(new ComparatorImie()));
        mapa.put(new User("c", "login"), 1234);
        mapa.put(new User("b", "login2"),7890);
        wyswietl(mapa);
    }

//    public static void zdanie;
    public static <T, S> void wyswietl(Map<T, S> mapa) {
        Set<Map.Entry<T, S>> entries = mapa.entrySet();
        for (Map.Entry<T, S> entry: entries) {
            System.out.println(entry.getKey().toString() + " : " + entry.getValue().toString());
        }
    }
}
