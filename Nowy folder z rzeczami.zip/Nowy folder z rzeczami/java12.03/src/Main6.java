import java.util.*;


public class Main6 {
    public static void main(String[] args) {
        List<Lista> ArrayList = new ArrayList<>();
        ArrayList.add(new Lista("kacper", 17));
        ArrayList.add(new Lista("adam", 20));
        ArrayList.add(new Lista("ania", 15));
        ArrayList.add(new Lista("asia", 30));
        wyswietl(ArrayList);
        ArrayList.remove(new Lista("adam", 20));
        wyswietl(ArrayList);



        Collections.reverse(ArrayList);
        wyswietl(ArrayList);

    }



    public static void wyswietl(List<Lista> listaa ) {
        Iterator<Lista> iterator = listaa.iterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
