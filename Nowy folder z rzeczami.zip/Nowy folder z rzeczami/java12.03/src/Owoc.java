import java.util.Objects;

public class Owoc implements Comparable<Owoc> {
    private String nazwa;
    private String kolor;

    public Owoc(String nazwa, String kolor) {
        this.nazwa = nazwa;
        this.kolor = kolor;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getKolor() {
        return kolor;
    }

    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Owoc)) return false;
        Owoc owoc = (Owoc) o;
        return Objects.equals(getNazwa(), owoc.getNazwa()) && Objects.equals(getKolor(), owoc.getKolor());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNazwa(), getKolor());
    }

    @Override
    public String toString() {
        return "Owoc{" +
                "nazwa='" + nazwa + '\'' +
                ", kolor='" + kolor + '\'' +
                '}';
    }

    @Override
    public int compareTo(Owoc o) {
        return this.getNazwa().compareTo(o.getNazwa());
    }
}
