import java.util.Objects;

public class User implements Comparable<User>{
    private String imie;
    private String login;

    public User(String imie, String login) {
        this.imie = imie;
        this.login = login;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return Objects.equals(getImie(), user.getImie()) && Objects.equals(getLogin(), user.getLogin());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getImie(), getLogin());
    }

    @Override
    public String toString() {
        return "User{" +
                "imie='" + imie + '\'' +
                ", login='" + login + '\'' +
                '}';
    }


    @Override
    public int compareTo(User o) {
        return this.getImie().compareTo(o.getImie());
    }
}
