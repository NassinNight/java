public class Zdanie {
}
