import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Random random = new Random();
//
//        int [] tab = new int[10];
//        for(int i=0;i< tab.length;i++) {
//            tab[i]=random.nextInt(0,10);
//        }
//        double [] tab2 = new double[10];
//        for(int e=0;e<tab.length;e++) {
//            tab2[e]=random.nextDouble(0.0,10.0);
//        }
//        wyswietl(tab);
//        System.out.println(" ");
//        wyswietl_od_tylu(tab);
//        System.out.println(" ");
//        wyswietl2(tab2);
//        System.out.println(" ");
//        wyswietl_od_tylu2(tab2);
//    }
//
//    public static void wyswietl(int [] tab) {
//        for(int i=0; i< tab.length; i++) {
//            System.out.print(tab[i] + " ");
//        }
//
//
//    }
//
//    public static void wyswietl_od_tylu(int [] tab) {
//        for(int i=tab.length-1; i>=0; i--) {
//            System.out.print(tab[i] + " ");
//        }
//    }
//    public static void wyswietl2(double [] tab) {
//        for(int i=0; i< tab.length; i++) {
////            System.out.print(tab[i] + " ");
//            System.out.format("%.2f%n",tab[i]);
//
//        }
//
//
//    }
//
//    public static void wyswietl_od_tylu2(double [] tab) {
//        for(int i=tab.length-1; i>=0; i--) {
//            //System.out.print(tab[i] + " ");
//            System.out.format("%.2f%n",tab[i]);
//        }
        Scanner scanner = new Scanner(System.in);
        Osoba osoba1 = new Osoba();
        System.out.println(osoba1.toString());
        Osoba osoba2 = new Osoba("Ania", 15, 158.0);
        System.out.println(osoba2.toString());
        Osoba osoba3 = new Osoba("Ania",15,158.0);
        System.out.println(osoba3.toString1());
        Osoba osoba4 = new Osoba("Jan", 174.6);
        System.out.println(osoba4.toString2());

        System.out.println("Podaj wzrost Ani");
        osoba2.setWzrost(scanner.nextInt());
        System.out.println(osoba2.toString());
        System.out.println(osoba1.getImie());
        System.out.println(osoba3.equals(osoba2));
    }


}
