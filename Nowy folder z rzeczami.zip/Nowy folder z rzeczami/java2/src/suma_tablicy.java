import java.util.Random;

public class suma_tablicy {
    public static void main(String[] args) {
        int [] tab = new int[10];
        Random random = new Random();
        int wynik=0;
        for(int i=0;i< tab.length;i++) {
            tab[i] = random.nextInt(0, 1000);
            System.out.println(i+1 + " liczba tablicy to: " + tab[i]);
            System.out.println("suma: " + String.valueOf(wynik=wynik+tab[i]));
        }


    }
}
