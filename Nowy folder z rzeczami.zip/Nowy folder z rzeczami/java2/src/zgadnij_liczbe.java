import java.util.Random;
import java.util.Scanner;

public class zgadnij_liczbe {
    public static void main(String[] args) {
        Random random = new Random();
        int liczba = random.nextInt(0,50);
        Scanner scanner = new Scanner(System.in);
        int liczba1=0;
//        int liczba1 = scanner.nextInt();
        int ile_prob = 0;
        long millisActualTimr = System.currentTimeMillis();
        while (true) {
            System.out.println("Podaj liczbe od 0 do 50: ");
            liczba1= scanner.nextInt();
            if (liczba1==liczba) {
                System.out.println("brawo zgadles");
                ile_prob=ile_prob+1;
                System.out.println("Ilosc prob: " + ile_prob);
                long executionTime = System.currentTimeMillis() - millisActualTimr;
                System.out.format("czas wykonania: " + "%f%n",(float)executionTime/1000);
                break;
            }
            if (liczba1>liczba) {
                System.out.println("Losowa liczba jest mniejsza");
                ile_prob=ile_prob+1;
            }
            if (liczba1<liczba) {
                System.out.println("losowa liczba jest wieksza");
                ile_prob=ile_prob+1;
            }
        }
    }
}
