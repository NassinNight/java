import static java.lang.Math.sqrt;

public class Main {
    public static void main(String[] args) {
//        string("Adam");
        int wiek = 18;
        char znak = 'a';
        String imie = "Kacper";
        boolean prawda = true;
        double przecinek = 3.5;
        int[] tab = {4, 5, 6, 7};
        String[] tab1 = new String[3];
        tab1[0] = "a";
        tab1[1] = "b";
        tab1[2] = "c";
        kwadratowa(1, 2, 1);

//        System.out.println(srednia(tab));
//        if (prawda == true) {
//            System.out.println("prawda");
//        }
//
//        switch (wiek) {
//            case 17:
//                System.out.println("17");
//                break;
//            case 18:
//                System.out.println("18");
//                break;
//            case 19:
//                System.out.println("19");
//                break;
//        }

//        for (int i = 0; i < tab.length; i++) {
//            tab[i] = i;
//            System.out.println(i);
//        }
//        for (String a : tab1) {
//            System.out.println(a);
//        }
//        while(prawda) {
//            System.out.println("x");
//            prawda=false;
//        }
//    }
//    public static void string(String imie) {
//        System.out.println(imie);
//    }
//
//    public static double srednia(int[] tab) {
//        double wynik=0;
//        int ii=0;
//        for (int i=0; i<tab.length;i++) {
//            wynik=wynik+tab[i];
//            ii=ii+1;
//        }
//        wynik=wynik/ii;
//        return wynik;
//    }

    }
        public static void kwadratowa ( int a, int b, int c){
            double delta = b * b - (4 * a * c);
            double x1 = (-b - sqrt(delta) / 2 * a);
            double x2 = (-b + sqrt(delta) / 2 * a);
            if (delta<0) {
                System.out.println(delta);
                System.out.println("nie ma miejsc zerowych");
            } else if (a==0) {
                System.out.println(delta);
                System.out.println(x1);
            } else if (delta==0) {
                System.out.println(delta);
                System.out.println(x1);
            } else {
                    System.out.println(delta);
                    System.out.println(x1);
                    System.out.println(x2);
                }
            }

        }

