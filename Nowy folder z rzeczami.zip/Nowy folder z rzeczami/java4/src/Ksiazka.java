import java.security.KeyStore;

public class Ksiazka {
    private String autor;
    private String tytul;
    private double cena;


    public Ksiazka(){
        autor="Mickiewicz";
        tytul="dziady";
        cena=15.99;
    }

    public Ksiazka(String autor, String tytul, double cena) {
        this.autor=autor;
        this.tytul=tytul;
        this.cena=cena;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setTytul(String tytul) {
        this.tytul = tytul;
    }


    public String getAutor() {
        return autor;
    }

    public String getTytul() {
        return tytul;
    }

    public void ustaw_cena(double cena) {
        if (czy_cena_dobra(cena)) {
            this.cena = cena;
        } else {
            System.out.println("nieprawidlowa cena");
        }
    }

    private boolean czy_cena_dobra(double cena) {
        if (cena>0) {
            return true;
        }
        return false;
    }

    public String toString() {
        return autor+ " " + tytul + " " + cena;
    }

}
