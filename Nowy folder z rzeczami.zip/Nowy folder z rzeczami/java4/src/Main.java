public class Main {
    public static void main(String[]args) {
        Ksiazka k1 = new Ksiazka();
        k1.setAutor("Slowacki");
        k1.ustaw_cena(-19.00);
       // System.out.println(k1.getAutor());
        System.out.println(k1.toString());
    }

}
