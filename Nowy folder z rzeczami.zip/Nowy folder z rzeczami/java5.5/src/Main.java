import java.awt.desktop.ScreenSleepEvent;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Kalkulator k1 = new Kalkulator(90, 0);
        try {
            Osoba o1 = new Osoba("kacper", "srodawa", -10);
        } catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
            System.out.println(e.getMessage());
        }

        try {
            Osoba o1 = new Osoba("kacper",null , 10);
        } catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
            System.out.println(e.getMessage());
        }

        try {
            Osoba o1 = new Osoba("kacper", null, -10);
        } catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
            System.out.println(e.getMessage());
        } catch(Exception e) {
            System.out.println(e.getMessage());

        }

//        boolean czy_podano_wiek = false;
//        int wiek = 0;
//
//        while (!czy_podano_wiek) {
//            try {
//                System.out.println("Podaj swoj wiek");
//                wiek = getInt();
//                czy_podano_wiek=true;
//            } catch(InputMismatchException e) {
//                System.out.println("musisz podac wiek");
//            } finally {
//                System.out.println(wiek);;
//            }
//        }

//        try {
//            System.out.println(podziel(10, 2));
//            System.out.println("poprawnie wykonano");
//        } catch(ArithmeticException e) {
//            System.out.println(e.getMessage());
//            System.out.println("blad");
//        } finally {
//            System.out.println("koniec dzialania");
//        }
//
//
//        try {
//            System.out.println(podziel(10, 0));
//            System.out.println("poprawnie wykonano");
//        } catch(ArithmeticException e) {
//            System.out.println(e.getMessage());
//            System.out.println("blad");
//        }finally {
//            System.out.println("koniec dzialania");
//        }
//
//        }

    }

        public static int getInt() {
            return new Scanner(System.in).nextInt();
        }
//        public static int podziel(int a, int b){
//            return a/b;
//        }
    }

