public class Osoba {
    private int wiek;
    private String imie;
    private String nazwisko;



    public Osoba(String imie, String nazwisko, int wiek) throws UjemnyWiekException, NieprawidlowaWartoscException {
        if (imie==null) {
            throw new NieprawidlowaWartoscException("Musisz podac imie");
        }
        if (nazwisko==null) {
            throw new NieprawidlowaWartoscException("Musisz podac nazwisko");
        }
        if(wiek<0) {
            throw new UjemnyWiekException("wiek nie moze byc ujemny");
        }
        this.wiek=wiek;
        this.imie=imie;
        this.nazwisko=nazwisko;
    }
}
