public class Kot extends Zwierze {
    public String imie;

    public Kot(){
        super("ssak", 10);
        imie="kot";
        System.out.println("jestem kotem");
    }

    public Kot(String imie) {
        super("ssak",10);
        this.imie=imie;
        System.out.println("jestem kotem");
    }
    public Kot(String gatunek, int wiek, String imie) {
        super(gatunek,wiek);
        this.imie=imie;
        System.out.println("jestem kotem");
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getImie() {
        return imie;
    }

    @Override
    public String toString() {
        return "Kot{" +
                "imie='" + imie + '\'' +
                ", gatunek='" + gatunek + '\'' +
                ", wiek=" + wiek +
                '}';
    }
}
