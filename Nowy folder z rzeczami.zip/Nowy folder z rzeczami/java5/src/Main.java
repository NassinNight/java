public class Main {
    public static void main(String[] args) {
        Zwierze zwierze = new Zwierze();
        Kot k1 = new Kot();
        Zwierze z2 = new Kot();
        //Kot k2 = (Kot) new Zwierze();



        ((Kot) z2).imie= "k1o1t";





        przedstaw_sie(z2);


    }




    public static void przedstaw_sie(Zwierze z) {
        System.out.println("hej " + z);
    }
}
