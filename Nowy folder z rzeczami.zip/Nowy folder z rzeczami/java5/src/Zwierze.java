public class Zwierze {
    public String gatunek;
    public int wiek;

    public Zwierze(String gatunek, int wiek) {
        this.gatunek=gatunek;
        this.wiek=wiek;
        System.out.println("jestem zwierzeciem");
    }

    public Zwierze(){
        gatunek="ssak";
        wiek=10;
        System.out.println("jestem zwierzeciem");
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public String getGatunek() {
        return gatunek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public int getWiek() {
        return wiek;
    }


    @Override
    public String toString() {
        return "Zwierze{" +
                "gatunek='" + gatunek + '\'' +
                ", wiek=" + wiek +
                '}';
    }
}
