public class Main {
    public static void main(String[]args) {
        Wlasciciel w1 = new Wlasciciel();
        Wlasciciel w2 = new Wlasciciel("Kacper", "Srodawa");
        Pies p1 = new Pies();
        Pies p2 = new Pies("Azor", "Doberman", w2);
        System.out.println(w1);
        System.out.println(w2);
        System.out.println(p1);
        System.out.println(p2);
    }
}
