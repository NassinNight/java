public class Pies {
    private final String imie;
    private final String rasa;
    private final Wlasciciel wlasciciel;

    public Pies() {
        imie = "reksio";
        rasa = "shihtzu";
        wlasciciel = new Wlasciciel();
    }

    public Pies(String imie, String rasa, Wlasciciel wlasciciel) {
        this.imie=imie;
        this.rasa = rasa;
        this.wlasciciel = wlasciciel;
    }
    public Wlasciciel getWlasciciel() {
        return wlasciciel;
    }

    public String getRasa() {
        return rasa;
    }

    public String getImie() {
        return imie;
    }

    public String toString() {
        return imie + " " +  " " + rasa + " " + wlasciciel;
    }
}
