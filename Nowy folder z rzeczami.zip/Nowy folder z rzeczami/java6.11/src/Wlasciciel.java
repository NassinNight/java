public class Wlasciciel {
    private final String imie;
    private final String nazwisko;

    public Wlasciciel() {
        imie="Jan";
        nazwisko="Kowalski";
    }

    public Wlasciciel(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }


    public String toString() {
        return imie + " " + nazwisko;
    }
}
