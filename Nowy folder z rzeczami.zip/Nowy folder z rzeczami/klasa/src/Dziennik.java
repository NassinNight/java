import java.util.Random;

public class Dziennik {
    String Wychowawca;

    int liczba_uczniow;

    char symbol;

    int[][] oceny;

    public Dziennik() {
        Wychowawca = "Jan Nowak";
        liczba_uczniow = 30;
        symbol = 'A';
        oceny = new int[31][2];
    }


    //SETTERY
            public void setWychowawca(String wychowawca) {
                this.Wychowawca=wychowawca;
            }
            public void setLiczba_uczniow(int liczba_uczniow) {
                this.liczba_uczniow=liczba_uczniow;
            }
            public void setSymbol(char symbol) {
                this.symbol=symbol;
            }



    //GETTERY
            public String getWychowawca() {
                return Wychowawca;
            }
            public int getLiczba_uczniow() {
                return liczba_uczniow;
            }
            public double getsymbol() {
                return symbol;
            }

    //RESZTA METOD




    public String toString() {
            return "\n Symbol: " + symbol + "\n Liczba Uczniow: " + liczba_uczniow + "\n Wychowawca: " + Wychowawca;

    }





}
