import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Random random = new Random();
        int[][] tab = new int[31][2];
        Dziennik dziennik = new Dziennik();
        System.out.println(dziennik.toString());
        System.out.println(" Oceny: ");
        for (int i = 1; i < tab.length; i++) {
            tab[i][0] = i;
            tab[i][1] = random.nextInt(1, 7);
            System.out.println(" " + tab[i][0] + " " + tab[i][1]);
        }


        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Wpisz zmien aby zmienic ocene");
            System.out.println("Wpisz usun aby usunac ocene");
            System.out.println("Wpisz podwyzsz aby podwyzszyc ocene");
            System.out.println("Wpisz zakoncz aby zamknac dziennik");
            String komenda = scanner.next();
            switch (komenda) {
                case "zmien":
                    System.out.println("Podaj numer ucznia od 1-30 ktoremu chcesz zmienic ocene");
                    int uczen = scanner.nextInt();
                    System.out.println("Podaj na jaka ocene od 1 do 6");
                    int ocena = scanner.nextInt();
                    tab[uczen][1] = ocena;
                    Dziennik dziennik1 = new Dziennik();
                    System.out.println(dziennik1.toString());
                    System.out.println(" Oceny: ");
                    for (int i = 1; i < tab.length; i++) {
                        for (int j=0;j<tab[i].length;j++) {
                            System.out.print(tab[i][j] + " ");
                        }
                        System.out.print("\n");
                    }
                    break;

                case "usun":
                    System.out.println("Podaj numer ucznia ktoremu chcesz usunac ocene");
                    int uczen1 = scanner.nextInt();
                    tab[uczen1][1] = -1;
                    Dziennik dziennik2 = new Dziennik();
                    System.out.println(dziennik2.toString());
                    System.out.println(" Oceny: ");
                    for (int i = 1; i < tab.length; i++) {
                        for (int j=0;j<tab[i].length;j++) {
                            System.out.print(tab[i][j] + " ");
                        }
                        System.out.print("\n");
                    }
                    break;

                case "podwyzsz":
                    System.out.println("Podaj numer ucznia ktoremu chcesz podwyzszyc ocene");
                    int uczen2 = scanner.nextInt();
                    tab[uczen2][1]++;
                    Dziennik dziennik3 = new Dziennik();
                    System.out.println(dziennik3.toString());
                    System.out.println(" Oceny: ");
                    for (int i = 1; i < tab.length; i++) {
                        for (int j=0;j<tab[i].length;j++) {
                            System.out.print(tab[i][j] + " ");
                        }
                        System.out.print("\n");
                    }
                    break;
                }
            if (komenda.equals("zakoncz")) {
                break;
            }
        }

    }
}
