public class Main {
    public static void main(String[]args) {
        Osoba o1 = new Osoba("Kacper", "Srodawa", 112233445);
        Osoba o2 = new Osoba("Julia", "Krol", 987654321);
        Osoba o3 = new Osoba("Adam", "Nowak", 192837465);
        Pracownik p1 = new Pracownik("Julia", "krol",987654321, 50,100);
        Pracownik p2 = new Pracownik("Adam","Nowak", 192837465,200,200);
        Urzednik u1 = new Urzednik();
        Urzednik u2 = new Urzednik(u1.getPremia(), u1.getStanowisko(), p1.getLiczba_godzin(), p1.getStawka(),o1.getImie(),o1.getNazwisko(),o1.getPesel());
        System.out.println(o1);
        System.out.println("----------------");
        System.out.println(o2);
        System.out.println("----------------");
        System.out.println(o3);
        System.out.println("----------------");
        System.out.println(p1);
        System.out.println("----------------");
        System.out.println(p2);
        System.out.println("----------------");
        System.out.println(u1);
        System.out.println("----------------");
        System.out.println(u2);
        System.out.println("----------------");
        o1.przedstaw_sie();
        System.out.println("----------------");
        p1.przedstaw_sie();
        System.out.println("----------------");
        u2.przedstaw_sie();
        System.out.println("----------------");
        u2.oblicz_pensje(p1.getLiczba_godzin(), p1.getStawka());
        System.out.println("----------------");
        u2.oblicz_pensje(p2.getLiczba_godzin(),p2.getStawka());

    }
}
