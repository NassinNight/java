public class Osoba{
    protected String imie;
    protected String nazwisko;
    protected int pesel;


    public Osoba() {
        imie="Ania";
        nazwisko="Nowak";
        pesel= 123456789;
    }

    public Osoba(String imie, String nazwisko, int pesel) {
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.pesel=pesel;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public int getPesel() {
        return pesel;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setPesel(int pesel) {
        this.pesel = pesel;
    }

    @Override
    public String toString() {
        return "Osoba{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", pesel=" + pesel +
                '}';
    }

    public void przedstaw_sie() {
        System.out.println("jestem czlowiekiem");
    }
}
