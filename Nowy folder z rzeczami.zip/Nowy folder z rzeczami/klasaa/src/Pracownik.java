import jdk.swing.interop.DropTargetContextWrapper;

public class Pracownik extends Osoba{
    protected int liczba_godzin;
    protected int stawka;

    public Pracownik() {
        liczba_godzin=40;
        stawka=35;
    }

    public Pracownik(int liczba_godzin, int stawka) {
        this.liczba_godzin=liczba_godzin;
        this.stawka=stawka;
    }

    public Pracownik(String imie, String nazwisko, int pesel, int liczba_godzin, int stawka) {
        super(imie, nazwisko, pesel);
        this.liczba_godzin=liczba_godzin;
        this.stawka=stawka;
    }



    public int getLiczba_godzin() {
        return liczba_godzin;
    }

    public void setLiczba_godzin(int liczba_godzin) {
        this.liczba_godzin = liczba_godzin;
    }

    public int getStawka() {
        return stawka;
    }

    public void setStawka(int stawka) {
        this.stawka = stawka;
    }


    @Override
    public String toString() {
        return "Pracownik{" +
                "liczba_godzin=" + liczba_godzin +
                ", stawka=" + stawka +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", pesel=" + pesel +
                '}';
    }

    @Override
    public void przedstaw_sie() {
        super.przedstaw_sie();
        System.out.println("jestem pracownikiem");
    }

    public void oblicz_pensje(int liczba_godzin, int stawka) {
        int pensja =liczba_godzin*stawka;
        System.out.println("moja pensja wynosi: " + pensja);
    }

}
