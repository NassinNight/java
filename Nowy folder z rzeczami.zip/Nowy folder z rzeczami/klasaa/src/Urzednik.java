public class Urzednik extends Pracownik{
    private int premia;
    private String stanowisko;

    public Urzednik() {
        premia=1000;
        stanowisko="prezes";
    }

    public Urzednik(int premia, String stanowisko) {
        this.premia=premia;
        this.stanowisko=stanowisko;
    }

    public Urzednik(int premia, String stanowisko, int liczba_godzin, int stawka) {
        super(liczba_godzin,stawka);
        this.premia=premia;
        this.stanowisko=stanowisko;
    }

    public Urzednik(int premia, String stanowisko, int liczba_godzin, int stawka, String imie, String nazwisko, int pesel) {
        super(imie,nazwisko,pesel,liczba_godzin,stawka);
        this.premia=premia;
        this.stanowisko=stanowisko;
    }

    public int getPremia() {
        return premia;
    }

    public void setPremia(int premia) {
        this.premia = premia;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    @Override
    public String toString() {
        return "Urzednik{" +
                "premia=" + premia +
                ", stanowisko='" + stanowisko + '\'' +
                ", liczba_godzin=" + liczba_godzin +
                ", stawka=" + stawka +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", pesel=" + pesel +
                '}';
    }

    @Override
    public void oblicz_pensje(int liczba_godzin, int stawka) {
        super.oblicz_pensje(liczba_godzin,stawka);
        int pensja =(liczba_godzin*stawka) + premia;
        System.out.println("Pensja pracownika z premia wynosi: " + pensja);
    }

    @Override
    public void przedstaw_sie() {
        super.przedstaw_sie();
        System.out.println("jestem urzednikiem");
    }
}
