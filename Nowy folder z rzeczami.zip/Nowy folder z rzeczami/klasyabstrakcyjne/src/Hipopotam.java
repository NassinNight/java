public class Hipopotam extends Zwierze{
    @Override
    public void wedruj() {
        System.out.println("plywam");
    }

    @Override
    public void jedz() {
        System.out.println("jem trawe");
    }

    @Override
    public void przedstawSie() {
        System.out.println("jestem hipopotamem");
    }
}
