public class Kot extends Kotowate implements ZwierzakDomowy{
    @Override
    public void jedz() {
        System.out.println("jem myszy");
    }

    @Override
    public void badzMilutki() {
        System.out.println("jestem mily");
    }

    @Override
    public void bawSie() {
        System.out.println("bawie sie drapakiem");
    }
}
