public abstract class Kotowate extends Zwierze{
    @Override
    public void wedruj() {
        System.out.println("skaradam sie");
    }

    @Override
    public void przedstawSie() {
        System.out.println("jestem kotem");
    }
}
