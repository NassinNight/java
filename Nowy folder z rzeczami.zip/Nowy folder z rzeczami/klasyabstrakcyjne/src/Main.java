public class Main {
    public static void main(String[] args) {
        Pies p = new Pies();
        Kot k = new Kot();
//        Zwierze z = new Zwierze();
        Zwierze [] zwierzeta = new Zwierze[3];
        zwierzeta[0]=p;
        zwierzeta[1]=k;

        jakaKlasa(p);
        jakaKlasa(k);

        System.out.println(p.terytorium);
        System.out.println(zmianaTerytorium(p).terytorium);

        p.bawSie();
        p.badzMilutki();
    }

    public static void jakaKlasa(Zwierze Zwierze) {
        System.out.println(Zwierze.getClass());
    }
    public static Zwierze zmianaTerytorium(Zwierze zwierze) {
        zwierze.terytorium= "Europa";
        return zwierze;
    }
}
