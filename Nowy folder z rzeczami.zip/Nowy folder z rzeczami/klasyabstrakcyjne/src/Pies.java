public class Pies extends Psowate implements ZwierzakDomowy{
    @Override
    public void jedz() {
        System.out.println("jem karme");
    }

    @Override
    public void przedstawSie() {
        System.out.println("jestem psem");
    }

    @Override
    public void badzMilutki() {
        System.out.println("jestem milutki");
    }

    @Override
    public void bawSie() {
        System.out.println("rzuc pilke");
    }
}
