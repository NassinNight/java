public class Tygrys extends Kotowate{
    @Override
    public void jedz() {
        System.out.println("poluje");
    }
}
