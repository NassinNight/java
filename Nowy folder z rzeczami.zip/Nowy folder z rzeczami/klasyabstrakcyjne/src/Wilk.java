public class Wilk extends Psowate {
    @Override
    public void jedz() {
        System.out.println("poluje");
    }
}
