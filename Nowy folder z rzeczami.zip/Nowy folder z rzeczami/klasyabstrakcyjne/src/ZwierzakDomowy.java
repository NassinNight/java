public interface ZwierzakDomowy {
    void badzMilutki();
    void bawSie();
}
