import java.util.Scanner;

public abstract class Zwierze {
    protected String terytorium;
    protected int glod;
    protected String pozywienie;

    public Zwierze() {
        terytorium = "Afryka";
        glod=10;
        pozywienie="trawa";
    }


    public Zwierze(String terytorium, int glod, String pozywienie) {
        this.terytorium = terytorium;
        this.glod=glod;
        this.pozywienie=pozywienie;
    }

    public void jedz() {
        System.out.println("jem");
    }

    public void wedruj() {
        System.out.println("wedruje");
    }

    public abstract void przedstawSie();

}
