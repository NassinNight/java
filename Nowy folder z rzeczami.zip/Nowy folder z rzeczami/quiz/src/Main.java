public class Main {
    public static void main(String[] args) throws InterruptedException {
        Quiz q1 = new Quiz();
    }
}