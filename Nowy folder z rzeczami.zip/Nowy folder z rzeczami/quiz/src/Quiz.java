import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Quiz extends JFrame implements ActionListener {
    JLabel label;
    JButton button11;
    JButton button12;
    JButton button13;
    JButton button14;

    JTextField tytul;
    JTextField timer;
    int wynik = 0;

    public Quiz() throws InterruptedException {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 800);
        this.setLayout(null);
        this.setTitle("Quiz");


        button11 = new JButton();
        button11.setText("Warszawa");
        button11.setBounds(200, 170, 100, 50);
        button11.addActionListener(this);

        button12 = new JButton();
        button12.setText("Krakow");
        button12.setBounds(200, 270, 100, 50);
        button12.addActionListener(this);

        button13 = new JButton();
        button13.setText("Wroclaw");
        button13.setBounds(200, 370, 100, 50);
        button13.addActionListener(this);

        button14 = new JButton();
        button14.setText("Poznan");
        button14.setBounds(200, 470, 100, 50);
        button14.addActionListener(this);


        tytul = new JTextField();
        tytul.setText("Jaka jest stolica Polski?");
        tytul.setBounds(100, 20, 300, 50);
        tytul.setHorizontalAlignment(SwingConstants.CENTER);
        tytul.setBorder(null);
        tytul.setEditable(false);
        tytul.setBackground(Color.yellow);
        tytul.setBorder(BorderFactory.createRaisedBevelBorder());

        timer = new JTextField();
        int a = 10;
             synchronized (this) {
                try {
                    this.wait(1000);
                    this.timer.setText(String.valueOf(a - 1));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

        timer.setBounds(450, 700, 50, 50);
        timer.setHorizontalAlignment(SwingConstants.CENTER);
        timer.setBorder(null);
        timer.setEditable(false);
        timer.setBackground(Color.yellow);
        timer.setBorder(BorderFactory.createRaisedBevelBorder());


        label = new JLabel();
        label.setBounds(390, 100, 50, 50);
        label.setOpaque(true);


        this.add(tytul);
        this.add(label);
        this.add(timer);
        this.add(button11);
        this.add(button12);
        this.add(button13);
        this.add(button14);
        this.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button11) {
            this.dispose();
            wynik = wynik + 1;
            Quiz2 quiz2 = new Quiz2(wynik);
        }
        if (e.getSource() == button12) {
            this.dispose();
            Quiz2 quiz2 = new Quiz2(wynik);
        }
        if (e.getSource() == button13) {
            this.dispose();
            Quiz2 quiz2 = new Quiz2(wynik);
        }
        if (e.getSource() == button14) {
            this.dispose();
            Quiz2 quiz2 = new Quiz2(wynik);

        }


    }
}
