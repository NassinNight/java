import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Quiz2 extends JFrame implements ActionListener {
    JLabel label;
    JButton button11;
    JButton button12;
    JButton button13;
    JButton button14;

    JTextField tytul;
    private int wynik;
    public Quiz2(int wynik) {
        this.wynik = wynik;
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 800);
        this.setLayout(null);
        this.setTitle("Quiz");


        button11= new JButton();
        button11.setText("Python");
        button11.setBounds(200,170,100,50);
        button11.addActionListener(this);

        button12= new JButton();
        button12.setText("Java");
        button12.setBounds(200,270,100,50);
        button12.addActionListener(this);

        button13= new JButton();
        button13.setText("Ruby");
        button13.setBounds(200,370,100,50);
        button13.addActionListener(this);

        button14= new JButton();
        button14.setText("C++");
        button14.setBounds(200,470,100,50);
        button14.addActionListener(this);



        tytul = new JTextField();
        tytul.setText("W jakim jezyku programujesz?");
        tytul.setBounds(100, 20, 300, 50);
        tytul.setHorizontalAlignment(SwingConstants.CENTER);
        tytul.setBorder(null);
        tytul.setEditable(false);
        tytul.setBackground(Color.yellow);
        tytul.setBorder(BorderFactory.createRaisedBevelBorder());



        label = new JLabel();
        label.setBounds(390, 100, 50, 50);
        label.setOpaque(true);


        this.add(tytul);
        this.add(label);
        this.add(button11);
        this.add(button12);
        this.add(button13);
        this.add(button14);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==button11) {
            this.dispose();
            Quiz3 quiz3 = new Quiz3(wynik);
        }
        if (e.getSource()==button12) {
            this.dispose();
            wynik=wynik+1;
            Quiz3 quiz3 = new Quiz3(wynik);
        }
        if (e.getSource()==button13) {
            this.dispose();
            Quiz3 quiz3 = new Quiz3(wynik);
        }
        if (e.getSource()==button14) {
            this.dispose();
            Quiz3 quiz3 = new Quiz3(wynik);

        }
    }
}
