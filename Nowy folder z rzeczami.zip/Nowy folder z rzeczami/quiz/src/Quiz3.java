import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Quiz3 extends JFrame implements ActionListener {
    JLabel label;
    JButton button11;
    JButton button12;
    JButton button13;
    JButton button14;

    JTextField tytul;
    private int wynik;
    JTextField wynikk;


    public Quiz3(int wynik) {
        this.wynik = wynik;
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 800);
        this.setLayout(null);
        this.setTitle("Quiz");



        tytul = new JTextField();
        tytul.setText("Twoj wynik to: ");
        tytul.setBounds(100, 20, 300, 50);
        tytul.setHorizontalAlignment(SwingConstants.CENTER);
        tytul.setBorder(null);
        tytul.setEditable(false);
        tytul.setBackground(Color.yellow);
        tytul.setBorder(BorderFactory.createRaisedBevelBorder());

        wynikk = new JTextField();
        wynikk.setText(String.valueOf(wynik) + "/2");
        wynikk.setBounds(200,200,100,50);
        wynikk.setHorizontalAlignment(SwingConstants.CENTER);
        wynikk.setBorder(null);
        wynikk.setEditable(false);
        wynikk.setBackground(Color.yellow);
        wynikk.setBorder(BorderFactory.createRaisedBevelBorder());

        label = new JLabel();
        label.setBounds(390, 100, 50, 50);
        label.setOpaque(true);


        this.add(tytul);
        this.add(label);
        this.add(wynikk);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}