public class Coupe extends Samochod implements Electric{
    private int czas_ladowania;

    public Coupe(int cena, String model, int rok_wydania, int czas_ladowania) {
        this.cena=200000;
        this.model="Tesla s";
        this.rok_wydania=2022;
        this.czas_ladowania=10;

    }

    public Coupe(int cena, String model, int rok_wydania) {
        super();
    }

    @Override
    public String toString() {
        return "Coupe{" +
                "czas_ladowania=" + czas_ladowania +
                ", cena=" + cena +
                ", model='" + model + '\'' +
                ", rok_wydania=" + rok_wydania +
                '}';
    }

    @Override
    public void naladuj() {
        System.out.println("zaczynam ladowanie");
    }
}
