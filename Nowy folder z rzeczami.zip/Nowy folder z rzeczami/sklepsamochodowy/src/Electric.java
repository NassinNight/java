public interface Electric {
    void naladuj();
}
