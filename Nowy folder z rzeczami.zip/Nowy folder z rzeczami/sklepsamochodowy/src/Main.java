import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Samochod[] lista = new Samochod[3];
        Samochod s1 = new MuscleCar(100000, "Dodge demon", 2017, 650);
        Samochod s2 = new Suv(150000, "Range Rover Velar", 2020, 2.3);
        Samochod s3 = new Coupe(200000, "Tesla S", 2022, 10);
        Sklep p1 = new Sklep();
        p1.dodaj_produkt(s1);
        p1.dodaj_produkt(s2);
        p1.dodaj_produkt(s3);
        p1.wyswietl();
        Coupe c1 = new Coupe(10000,"a", 2020, 23);
    }
}