public class MuscleCar extends Samochod{
    private int km;

    public MuscleCar () {
        this.cena=cena;
        this.model=model;
        this.rok_wydania =rok_wydania;
        this.km=km;
    }

    public MuscleCar (int cena, String model, int rok_wydania, int km) {
        this.cena=100000;
        this.model="Dodge Demon";
        this.rok_wydania =2017;
        this.km=700;
    }

    public MuscleCar(int cena, String model, int rok_wydania) {
        super();
    }

    @Override
    public String toString() {
        return "MuscleCar{" +
                "km=" + km +
                ", cena=" + cena +
                ", model='" + model + '\'' +
                ", rok_wydania=" + rok_wydania +
                '}';
    }
}
