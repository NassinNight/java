public abstract class Samochod{
    protected int cena;
    protected String model;
    protected int rok_wydania;



    public Samochod() {
        this.cena = cena;
        this.model = model;
        this.rok_wydania = rok_wydania;
    }

    @Override
    public String toString() {
        return "Samochod{" +
                "cena=" + cena +
                ", model='" + model + '\'' +
                ", rok_wydania=" + rok_wydania +
                '}';
    }
}
