public class Sklep {
    private Samochod[] lista;
    private int index;

    public Sklep() {
        this.lista = new Samochod[10];
        this.index = 0;
    }

    public void dodaj_produkt(Samochod samochod) {
        lista[index]=samochod;
        index=index+1;
    }

    public void wyswietl() {

        for (Samochod p : lista) {
            if (p != null) {
                System.out.println(p);
            }


        }
    }
}
