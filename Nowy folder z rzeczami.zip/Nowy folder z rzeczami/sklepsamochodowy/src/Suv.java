public class Suv extends Samochod{
    private double wysokosc;

    public Suv(int cena, String model, int rok_wydania,double wysokosc) {
        this.cena=70000;
        this.model="Range Rover Velar";
        this.rok_wydania=2020;
        this.wysokosc = 2.3;
    }

    public Suv(int cena, String model, int rok_wydania) {
        super();
    }

    @Override
    public String toString() {
        return "Suv{" +
                "wysokosc=" + wysokosc +
                ", cena=" + cena +
                ", model='" + model + '\'' +
                ", rok_wydania=" + rok_wydania +
                '}';
    }
}
