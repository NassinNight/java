import java.io.*;

public class Deserializacja {
    public static void main(String[] args) {
     try {
         FileInputStream stream = new FileInputStream("obiekty.ser");
         ObjectInputStream os = new ObjectInputStream(stream);

         Object object =os.readObject();
         Object object2 =os.readObject();
         Object object3 =os.readObject();

        Postac p1 = (Postac) object;
        Postac p2 = (Postac) object2;
        Postac p3 = (Postac) object3;

         System.out.println(p1);
         System.out.println(p2);
         System.out.println(p3);

         os.close();


     } catch (IOException | ClassNotFoundException e)  {
         System.out.println(e.getMessage());
     }
    }
}
