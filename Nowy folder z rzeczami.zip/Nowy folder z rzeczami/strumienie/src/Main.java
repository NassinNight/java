import java.io.File;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        File file = new File("plik.txt");
        File file2 = new File("files");
        file2.mkdir();

        if (file2.isDirectory()) {
            String[] zawartosc = file2.list();
            for(int i = 0; i< zawartosc.length;i++) {
                System.out.println(zawartosc[i]);
            }
        }
        System.out.println(file2.getAbsolutePath());

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
        System.out.println(file.getAbsolutePath());
    }
}
