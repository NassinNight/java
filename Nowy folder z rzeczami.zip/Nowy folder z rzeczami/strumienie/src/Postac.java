import java.io.Serializable;

public class Postac implements Serializable {
    private String rasa;
    private int hp;
    private ap ap;
    transient private int ad;

    public Postac() {
        rasa="yordl";
        hp=1800;
        ap=new ap();
        ad=130;
    }

    public Postac(String rasa, int hp, int ap, int ad) {
        this.rasa=rasa;
        this.hp=hp;
        this.ap=new ap();
        this.ad=ad;
    }

    public String getRasa() {
        return rasa;
    }

    public void setRasa(String rasa) {
        this.rasa = rasa;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }




    public int getAd() {
        return ad;
    }

    public void setAd(int ad) {
        this.ad = ad;
    }


    @Override
    public String toString() {
        return "Postac{" +
                "rasa='" + rasa + '\'' +
                ", hp=" + hp +
                ", ap=" + ap.getWartosc() +
                ", ad=" + ad +
                '}';
    }
}
