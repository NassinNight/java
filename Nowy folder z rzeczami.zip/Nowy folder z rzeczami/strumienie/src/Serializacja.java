import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serializacja {
    public static void main(String[] args) {
        Postac yordl = new Postac();
        Postac elf = new Postac("elf", 2400, 500,100);
        Postac troll = new Postac("troll", 4600, 30, 240);

        System.out.println(yordl);
        System.out.println(elf);
        System.out.println(troll);

        File file = new File("obiekty.ser");

        try{
            FileOutputStream stream = new FileOutputStream(file);
            ObjectOutputStream so = new ObjectOutputStream(stream);

            so.writeObject(yordl);
            so.writeObject(elf);
            so.writeObject(troll);

            so.close();


        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
