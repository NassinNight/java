import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Zapisdopliku {
    public static void main(String[] args) {
        String wiadomosc = "hello world";
        String[] wiadomosci = {"czesc","aa", "asas", "weer", "wrgw", "we4"};
        int [] lata = {1234,2313,2212,4231,214,1241,4124};



        try {
            FileWriter writer = new FileWriter(new File("zapis.txt"));
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.write(wiadomosc);
            buffer.newLine();
            buffer.flush();
            for (int i=0; i< wiadomosci.length; i ++) {
                buffer.write(wiadomosci[i]);
                buffer.newLine();
            }
            buffer.newLine();
            for (int i=0;i< lata.length; i ++) {
                buffer.write(Integer.toString(lata[i]));
                buffer.newLine();
            }



            buffer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
