import java.io.Serializable;

public class ap implements Serializable  {

    private int wartosc;

    public ap() {
        wartosc=-1;
    }

    public ap(int ap){
        wartosc=ap;
    }

    public int getWartosc() {
        return wartosc;
    }

    public void setWartosc(int wartosc) {
        this.wartosc = wartosc;
    }
}
