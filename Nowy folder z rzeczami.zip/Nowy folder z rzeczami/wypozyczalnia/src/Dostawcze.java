public class Dostawcze extends Pojazd{
    protected int ograniczeniePredkosci;
    protected int ladownosc;
    public Dostawcze(int nrRejestracyjny, String kolor, int cena, int spalanie, int licznikKm, int zbiornikPaliwa, int maxPojemnoscZbiornika, int ograniczeniePredkosci, int ladownosc) {
        super(nrRejestracyjny, kolor, cena, spalanie, licznikKm, zbiornikPaliwa, maxPojemnoscZbiornika);
        this.ograniczeniePredkosci=ograniczeniePredkosci;
        this.ladownosc=ladownosc;
    }


    @Override
    public void jedz() {
        System.out.println("wioze towar");
    }

    @Override
    public String toString() {
        return "Dostawcze{" +
                "ograniczeniePredkosci=" + ograniczeniePredkosci +
                ", ladownosc=" + ladownosc +
                ", nrRejestracyjny=" + nrRejestracyjny +
                ", kolor='" + kolor + '\'' +
                ", cena=" + cena +
                ", spalanie=" + spalanie +
                ", licznikKm=" + licznikKm +
                ", zbiornikPaliwa=" + zbiornikPaliwa +
                ", maxPojemnoscZbiornika=" + maxPojemnoscZbiornika +
                '}';
    }
}
