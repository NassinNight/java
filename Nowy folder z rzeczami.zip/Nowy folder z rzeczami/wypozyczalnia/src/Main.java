public class Main {
    public static void main(String[] args) {
        Pojazd o1 = new Osobowe(102938447, "zolty", 60000, 7, 20000, 30, 50, "skoda", 5);
        Pojazd d1 = new Dostawcze(110011002, "szary", 120000, 12, 0, 70, 130, 110, 25);
        Pojazd m1 = new Motocykle(987654321, "niebieski", 30000, 3, 7000, 13, 30, "yamaha", 2);
        System.out.println(o1.toString());
        System.out.println(d1.toString());
        System.out.println(m1.toString());
        o1.jedz();
        d1.jedz();
        m1.jedz();
        o1.tankuj();
        d1.tankuj();
        m1.tankuj();
        System.out.println(o1.toString());
        System.out.println(d1.toString());
        System.out.println(m1.toString());
    }
}
