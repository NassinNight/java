public class Motocykle extends Pojazd{
    protected String marka;
    protected int dopuszczalnaIloscPasazerow;



    public Motocykle(int nrRejestracyjny, String kolor, int cena, int spalanie, int licznikKm, int zbiornikPaliwa, int maxPojemnoscZbiornika, String marka, int dopuszczalnaIloscPasazerow) {
        super(nrRejestracyjny, kolor, cena, spalanie, licznikKm, zbiornikPaliwa, maxPojemnoscZbiornika);
        this.marka=marka;
        this.dopuszczalnaIloscPasazerow=dopuszczalnaIloscPasazerow;
    }

    @Override
    public void jedz() {
        System.out.println("jade na jednym kole");
    }

    @Override
    public String toString() {
        return "Motocykle{" +
                "marka='" + marka + '\'' +
                ", dopuszczalnaIloscPasazerow=" + dopuszczalnaIloscPasazerow +
                ", nrRejestracyjny=" + nrRejestracyjny +
                ", kolor='" + kolor + '\'' +
                ", cena=" + cena +
                ", spalanie=" + spalanie +
                ", licznikKm=" + licznikKm +
                ", zbiornikPaliwa=" + zbiornikPaliwa +
                ", maxPojemnoscZbiornika=" + maxPojemnoscZbiornika +
                '}';
    }
}
