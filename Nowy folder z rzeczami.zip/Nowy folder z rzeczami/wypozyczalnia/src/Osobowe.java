public class Osobowe extends Pojazd{
    protected int liczbaDrzwi;
    protected String marka;



    public Osobowe(int nrRejestracyjny, String kolor, int cena, int spalanie, int licznikKm, int zbiornikPaliwa, int maxPojemnoscZbiornika, String marka, int liczbaDrzwi) {
        super(nrRejestracyjny, kolor, cena, spalanie, licznikKm, zbiornikPaliwa, maxPojemnoscZbiornika);
        this.marka=marka;
        this.liczbaDrzwi=liczbaDrzwi;
    }

    @Override
    public void jedz() {
        System.out.println("jade");
    }

    @Override
    public String toString() {
        return "Osobowe{" +
                "liczbaDrzwi=" + liczbaDrzwi +
                ", marka='" + marka + '\'' +
                ", nrRejestracyjny=" + nrRejestracyjny +
                ", kolor='" + kolor + '\'' +
                ", cena=" + cena +
                ", spalanie=" + spalanie +
                ", licznikKm=" + licznikKm +
                ", zbiornikPaliwa=" + zbiornikPaliwa +
                ", maxPojemnoscZbiornika=" + maxPojemnoscZbiornika +
                '}';
    }

}
