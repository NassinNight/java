public abstract class Pojazd {
    protected int nrRejestracyjny;
    protected String kolor;
    protected int cena;
    protected int spalanie;
    protected int licznikKm;
    protected int zbiornikPaliwa;
    protected int maxPojemnoscZbiornika;


    public Pojazd(int nrRejestracyjny, String kolor, int cena, int spalanie, int licznikKm, int zbiornikPaliwa) {
        this.nrRejestracyjny =123456789;
        this.kolor ="czarny";
        this.cena =100000;
        this.spalanie =6;
        this.licznikKm =3000;
        this.zbiornikPaliwa =30;
        maxPojemnoscZbiornika=50;
    }

    public Pojazd(int nrRejestracyjny, String kolor, int cena, int spalanie, int licznikKm, int zbiornikPaliwa, int maxPojemnoscZbiornika) {
        this.nrRejestracyjny = nrRejestracyjny;
        this.kolor = kolor;
        this.cena = cena;
        this.spalanie = spalanie;
        this.licznikKm = licznikKm;
        this.zbiornikPaliwa = zbiornikPaliwa;
        this.maxPojemnoscZbiornika = maxPojemnoscZbiornika;
    }

    public void tankuj() {
        zbiornikPaliwa=maxPojemnoscZbiornika;
    }

    public abstract void jedz();


}
