import java.util.Comparator;

public class ComparatorAutor implements Comparator<Ksiazka> {

    @Override
    public int compare(Ksiazka o1, Ksiazka o2) {
        return o1.getAutor().getNazwisko().compareTo(o2.getAutor().getNazwisko());
    }
}
