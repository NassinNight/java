import java.util.Comparator;

public class ComparatorNazwa implements Comparator<Kolor> {
    @Override
    public int compare(Kolor o1, Kolor o2) {
        return o1.getNazwa().compareTo(o2.getNazwa());
    }
}
