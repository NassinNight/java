import java.util.Comparator;

public class ComparatorRokWydania implements Comparator<Ksiazka> {
    @Override
    public int compare(Ksiazka o1, Ksiazka o2) {
        return o2.getRokWydania() - o1.getRokWydania();
    }
}
