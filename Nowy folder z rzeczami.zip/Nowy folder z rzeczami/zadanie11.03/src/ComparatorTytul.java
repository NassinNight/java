import java.util.Comparator;

public class ComparatorTytul implements Comparator<Ksiazka> {
    @Override
    public int compare(Ksiazka o1, Ksiazka o2) {
        return o1.getTytul().compareTo(o2.getTytul());
    }
}
