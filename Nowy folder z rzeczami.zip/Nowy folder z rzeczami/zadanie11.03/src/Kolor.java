import java.util.Objects;

public class Kolor{
    private String nazwa;

    public Kolor(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Kolor)) return false;
        Kolor kolor = (Kolor) o;
        return Objects.equals(getNazwa(), kolor.getNazwa());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNazwa());
    }

    @Override
    public String toString() {
        return "Kolor{" +
                "nazwa='" + nazwa + '\'' +
                '}';
    }
}
