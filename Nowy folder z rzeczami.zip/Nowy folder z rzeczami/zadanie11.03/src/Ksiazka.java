public class Ksiazka {
    private String tytul;
    private Autor autor;
    private int rokWydania;

    public Ksiazka(String tytul, Autor autor, int rokWydania) {
        this.tytul=tytul;
        this.autor = autor;
        this.rokWydania=rokWydania;

    }

    public Ksiazka(String tytul, int rokWydania) {
        super();
    }

    public String getTytul() {
        return tytul;
    }

    public void setTytul(String tytul) {
        this.tytul = tytul;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

    public int getRokWydania() {
        return rokWydania;
    }

    public void setRokWydania(int rokWydania) {
        this.rokWydania = rokWydania;
    }

    @Override
    public String toString() {
        return "Ksiazka{" +
                "tytul='" + tytul + '\'' +
                ", autor=" + autor +
                ", rokWydania=" + rokWydania +
                '}';
    }
}
