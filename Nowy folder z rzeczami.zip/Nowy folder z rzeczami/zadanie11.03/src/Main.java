import java.util.*;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {

        List<Kolor> paleta = new ArrayList<>();
        paleta.add(new Kolor("zolty"));
        paleta.add(new Kolor("niebieski"));
        paleta.add(new Kolor("czerwony"));
        paleta.add(new Kolor("bialy"));
        paleta.add(new Kolor("zielony"));
        paleta.add(new Kolor("czarny"));
        paleta.add(new Kolor("szary"));
        paleta.add(new Kolor("rozowy"));
        wyswietl(paleta);
        System.out.println(" ");
        System.out.println("dodwanie pomaranczowego");
        paleta.set(1,new Kolor("pomaranczowy"));
        wyswietl(paleta);
        System.out.println(" ");

        System.out.println("usuwanie rozowego");
        paleta.remove(7);
        wyswietl(paleta);
        System.out.println(" ");

        System.out.println("dodawanie brazowego");
        paleta.add(0,new Kolor("brazowy"));
        wyswietl(paleta);
        System.out.println(" ");

        System.out.println("rozmiar palety");
        System.out.println(paleta.size());
        System.out.println(" ");

        System.out.println("usun pomaranczowy");
        paleta.remove(new Kolor("pomaranczowy"));
        wyswietl(paleta);
        System.out.println(" ");

        System.out.println("czy jest pusta?");
        System.out.println(paleta.isEmpty());
        System.out.println(" ");

        System.out.println("gdzie jest zielony?");
        System.out.println(paleta.indexOf(new Kolor("zielony")));
        System.out.println(" ");





        ComparatorNazwa comparatorNazwa = new ComparatorNazwa();
        Collections.sort(paleta,comparatorNazwa);
        wyswietl(paleta);






    }
    public static void wyswietl(List<Kolor> paleta ) {
        Iterator<Kolor> iterator = paleta.iterator();
        int i=0;
        while(iterator.hasNext()) {
            i++;
            System.out.println(i + " " + iterator.next().toString());
        }
    }
}