import java.util.*;

public class Main2 {
    public static void main(String[]args) {
        List<Student> klasa = new ArrayList<>();
        klasa.add(new Student("Jan", "Nowak", 0));
        klasa.add(new Student("Adam", "Kowalczyk", 3));
        klasa.add(new Student("Ewa", "Strzelczyk", 4));
        klasa.add(new Student("Tomek", "Konieczny", 2));
        klasa.add(new Student("Kacper", "Srodawa", 1));
        klasa.add(new Student("Ania", "Nowaczyk", 6));
        klasa.add(new Student("Asia", "Lewandowski", 7));
        klasa.add(new Student("Pawel", "Kowalski", 5));

        ComparatorImie comparatorImie = new ComparatorImie();
        Collections.sort(klasa, comparatorImie);
        wyswietl(klasa);
        System.out.println(" ");
        ComparatorNazwisko comparatorNazwisko = new ComparatorNazwisko();
        Collections.sort(klasa, comparatorNazwisko);
        wyswietl(klasa);
        System.out.println(" ");
        ComparatorIndex comparatorIndex = new ComparatorIndex();
        Collections.sort(klasa, comparatorIndex);
        wyswietl(klasa);

    }

    public static void wyswietl(List<Student> klasa) {
        Iterator<Student> iterator = klasa.iterator();
        int i=0;
        while(iterator.hasNext()) {
            i++;
            System.out.println(i + " " + iterator.next().toString());
        }
    }
}
