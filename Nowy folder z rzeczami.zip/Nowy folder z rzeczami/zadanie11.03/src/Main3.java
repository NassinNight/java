import java.util.ArrayList;
import java.util.List;
import java.util.*;


public class Main3 {
    public static void main(String[]args) {
        List<Ksiazka> biblioteka = new ArrayList<>();
        biblioteka.add(new Ksiazka("Pan Tadeusz",new Autor("Pan tadeusz", 1900, "Adam", "Mickiewicz", 1880), 1900));
        biblioteka.add(new Ksiazka("Zona modna",new Autor("Zona modna", 1677, "Ignacy", "Krasinski", 1650),1677));
        biblioteka.add(new Ksiazka("Potop",new Autor("Potop", 1860, "Henryk", "Sienkiewicz", 1812),1860));
        biblioteka.add(new Ksiazka("Balladyna",new Autor("Balladyna", 1878, "Juliusz", "Slowacki", 1862),1878));
        wyswietl(biblioteka);
        System.out.println(" ");

        ComparatorTytul comparatorTytul =new ComparatorTytul();
        Collections.sort(biblioteka,comparatorTytul);
        wyswietl(biblioteka);
        System.out.println(" ");
        ComparatorRokWydania comparatorRokWydania = new ComparatorRokWydania();
        Collections.sort(biblioteka,comparatorRokWydania);
        wyswietl(biblioteka);
        System.out.println(" ");

        ComparatorAutor comparatorAutor = new ComparatorAutor();
        Collections.sort(biblioteka,comparatorAutor);
        wyswietl(biblioteka);
        System.out.println(" ");

    }
    public static void wyswietl(List<Ksiazka> klasy ) {
        Iterator<Ksiazka> iterator = klasy.iterator();
        int i=0;
        while(iterator.hasNext()) {
            i++;
            System.out.println(i + " " + iterator.next().toString());
        }
    }
}
