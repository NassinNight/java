import java.util.Scanner;

public class Main {
    public static void main(String[]args) {
        //     Silnia s1 = new Silnia(3);
        try {
            Silnia s2 = new Silnia(10);
        } catch (BlednaWartoscException e) {
            System.out.println("a");
        }





//    public static int silnia(int n) {
//        if (n<0) {
//            try {
//                throw new BlednaWartoscException("chuj");
//            } catch (BlednaWartoscException e) {
//                throw new RuntimeException(e);
//            }
//        }
//        int i=0;
//        int wynik=1;
//        for (i=1; i==n; i++) {
//            wynik=wynik*i;
//            System.out.println("a");
//        }
//        try {
//            System.out.println("podaj wiek");
//            n=getInt();
//            int i=0;
//            for (i=0; i==n; i++) {
//                wynik=wynik*i;
//            }
//        } catch (BlednaWartoscException e) {
//            System.out.println("n nie moze byc ujemne");
//        } finally {
//            System.out.println(wynik);
//        }
//        System.out.println(silnia(getInt()));
//        return wynik;
//    }



        }


    }

