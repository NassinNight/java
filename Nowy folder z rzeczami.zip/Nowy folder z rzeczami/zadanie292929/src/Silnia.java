public class Silnia extends Main {
    private int n;

    public Silnia(int n) throws BlednaWartoscException {
        if (n < 0) {
            System.out.println("a");
            throw new BlednaWartoscException("aaaaaaaaa");
        } else {
            System.out.println("a");
            int wynik=1;
            int i=1;
            System.out.println("a");
            while (i<n) {

                wynik=wynik*i;
                System.out.println("a");
                i++;
                System.out.println(wynik);
            }
        }
    }
}



