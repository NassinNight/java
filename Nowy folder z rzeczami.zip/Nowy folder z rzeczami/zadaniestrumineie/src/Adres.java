public class Adres {
    public static void main(String[] args
    }
}
