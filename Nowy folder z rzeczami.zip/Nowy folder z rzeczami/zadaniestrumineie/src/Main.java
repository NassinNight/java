import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        String[] pacjent = {"Imie: Kacper", "Nazwisko: Srodawa", "Data urodzenia: 28.05.2005", "Pesel: 123456789"};


        try {
            FileWriter writer = new FileWriter(new File("zapis.txt"),true);
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.write("--------------");
            buffer.newLine();
            buffer.flush();
            for (int i = 0; i < pacjent.length; i++) {
                buffer.write(pacjent[i]);
                buffer.newLine();
            }
            buffer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
