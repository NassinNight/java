import java.io.*;

public class Odczyt {
    public static void main(String[] args) {
        File file = new File("plik.txt");
        int slowa = 0;
        int wiersze = 0;
        int znaki = 0;

        try {
            FileReader reader = new FileReader(file);
            BufferedReader buffer = new BufferedReader(reader);


            System.out.println("--------------------");


            String wiersz = "";
            while ((wiersz = buffer.readLine()) != null) {
                String[] divide = wiersz.split("\\s+");
                for (String slowo : divide) {
                    slowa = slowa + 1;
                    System.out.println(slowo);
                }
                divide = wiersz.split("");
                for (String slowo1 : divide) {
                    znaki = znaki + 1;
                    System.out.println(slowo1);
                }
                divide = wiersz.split("}");
                for (String slowo2 : divide) {
                    wiersze = wiersze + 1;
                    System.out.println(slowo2);
                }




            }
            buffer.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("wiersze: " + wiersze);
        System.out.println("slowa: " + slowa);
        System.out.println("znaki: " + znaki);
    }
}
